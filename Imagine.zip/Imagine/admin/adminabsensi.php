<?php

	
	if(isset($_SESSION['username'],$_SESSION['password'],$_SESSION['status'])){
		if($_SESSION['status']!=2){
			echo"<script>alert('Anda tidak berhak mengakses file ini!');document.location='../index.php';</script>";
		}
	}else{
		echo"<script>alert('Anda tidak berhak mengakses file ini!');document.location='../index.php';</script>";
	}
?>
<tr><td><a href="./">| Back |</td></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<!--
<tr>
<td><a href="?v=forminputsiswa"><img src="gambar/add.jpg" title="Input Siswa" height="30" width="25"></td></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<td><a href="?v=updatesiswa"><img src="gambar/edit.ico" title="Edit Siswa" height="30" width="25"></td></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<td><a href="?v=deletesiswa"><img src="gambar/delete.png" title="Edit Siswa" height="30" width="25"></td></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</tr></br>-->
		<a href="?v=forminputsiswa" align="left">| Input Siswa |</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		

		
		<h2 align='center'><br>Daftar Nama Siswa</h2><br>
			<table>
			<tr>
				<td>
					Kelas :</td>
				<form action="?v=class" method="post">	
				<td><select  onchange="this.form.submit()" name="id_program"  >
							<option value="">- Search -</option>
							<option value="all">All</option>
							<?php

							$person=mysql_query("SELECT * FROM tb_program ");
								while($data=mysql_fetch_array($person)){
									echo "<option value=\"$data[id_program]\">$data[nama_program]</option>";		}
							?>
					</select></td>
			
					</form>
				</td>
				
					<td>
					<form action="?v=search" method="post">
						<input type="text" name="search" placeholder="Pencarian"/>
						
					</form> 
					</td>
			</tr>
			</table></br>
	  <?php
	  $sql=mysql_query("select a.id_siswa, a.nama_siswa, a.phone,a.id_status, a.kampus, a.facebook, a.tgl_daftar, b.jenis_person, c.nama_program, d.status from tb_siswa a, tb_person b, tb_program c, tb_status d where a.id_status='1' 
	  and a.id_person=b.id_person and a.id_program=c.id_program and a.id_status=d.id_status ");
 
  ?>
     
       
        <table width="100%" cellpadding="2" border="1">
          
		  <tr>
			  <th  style="background:#5A5C5C" ><font color="#ffffff" width="3">No</font></th>
				   <th  style="background:#5A5C5C" width="20%"><font color="#ffffff">Nama</font></th>
						<th  style="background:#5A5C5C" width="10%"><font color="#ffffff">Phone</font></th>
					  <th  style="background:#5A5C5C" width="10%"><font color="#ffffff">Kampus</font></th>
			
  				   <th  style="background:#5A5C5C" width="15%"><font color="#ffffff">Facebook</font></th>
								<th  style="background:#5A5C5C" width="10%"><font color="#ffffff">Tanggal Daftar</font></th>
										<th  style="background:#5A5C5C" width="15%"><font color="#ffffff">Kelas</font></th>
			   <th  style="background:#5A5C5C" width="10%"><font color="#ffffff">Status</font></th>
		   <th  style="background:#5A5C5C" width="15%"><font color="#ffffff">Action</font></th>
			 
            </tr>
		
	<?php
		   $nomor=1;
		   while($data=mysql_fetch_array($sql))		  
		   {
		   		if(($nomor % 2)== 0){
		   			$bgcolor="#F7D891";
			}else{
				$bgcolor="#F7F6DE";
			}
				$nama= $data['id_siswa'];
		   ?>
                     <tbody>
			<tr bgcolor="<?php echo $bgcolor;?>";>
			 <td ><?php echo" $nomor"?></td>
			 <td><?php echo" $data[nama_siswa]"?></td>
			  <td><?php echo" $data[phone]"?></td>
			  <td ><?php echo" $data[kampus]"?></td>
			  		  <td><?php echo" $data[nama_program]"?></td>
			  <td><?php echo" $data[facebook]"?></td>
						  <td ><?php echo" $data[tgl_daftar]"?></td>
			  <td><?php echo" $data[jenis_person]"?></td>
			 <td> <a href="?v=updatesiswa&id_siswa=<?php echo "$nama"?>"><b>Edit</b></a> | 
		<a href="?v=prosesdelete&id_siswa=<?php echo "$nama";?>" onclick= "return confirm ('Anda yakin akan menghapus?')"><b>Delete</b></a></td>
            </tr>
		
			<?php 
			$nomor++; 
			}
			
			?>
          </tbody>
        <?php echo "</table>"?>