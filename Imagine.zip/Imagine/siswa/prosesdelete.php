<?php

 include_once("C:/xampp/htdocs/fix/koneksi/koneksi.php");
  
	$id_siswa = $_GET ['id_siswa'];
	                      
$query = mysql_query("UPDATE tb_siswa SET id_status=2 WHERE id_siswa='$id_siswa'") or die (mysql_error());
if($query){
	echo "<script>
	 
		  document.location='?v=adminsiswa';
		  	  return true;
   </script>";
}else{
echo "<script>alert('Delete Failed');document.location='?v=deletesiswa';</script>";
}
?>
