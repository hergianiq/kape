<?php

 include_once("../koneksi/koneksi.php");
  
	$id_siswa = $_POST ['id_siswa'];
     $nama_siswa = $_POST['nama_siswa'];
     $phone = $_POST['phone'];
     $kampus = $_POST['kampus'];  
     $kelas= $_POST['id_program'];	 
	 $tgl_daftar = $_POST['tgl_daftar'];
	 $id_person = $_POST['id_person'];
                 
$query = mysql_query("UPDATE tb_siswa SET nama_siswa='$nama_siswa',phone='$phone',kampus='$kampus',id_program='$kelas', tgl_daftar='$tgl_daftar', id_person='$id_person' WHERE id_siswa='$id_siswa'") or die (mysql_error());
if($query){
echo "<script>document.location='../index.php?v=adminsiswa';</script>";
}else{
echo "<script>document.location='formupdatesiswa.php';</script>";
}
?>