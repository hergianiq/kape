<table style="width:100%; ">
		<tr>
				<th style="solid black; color:;  background:#a0b1b4;">Nama</th>
				<th style="solid black;color:;  background:#a0b1b4;">No. Hp</th>
				<th style="solid black; color:;  background:#a0b1b4;">Email</th>
				<th style="solid black; color:;  background:#a0b1b4;">alamat</th>
		</tr>
		<?php
			if(isset($_POST['tombol'])){
				$jenis=$_POST['jenis_obat'];
			$mysql=mysql_query("SELECT * FROM tb_obat WHERE jenis_obat='$jenis'"); //utk memanggil query di DB
				$m=1;										// variabel untuk tampilan td
				while($jenis_obat=mysql_fetch_array($mysql)){ //pengulangan untuk mengambil data dari DB
				if($m%2==0){echo"<tr style=\"background:#bbc0bc; color:black;\">";}else{echo"</tr>";} //kondisi jika m : 2 sisa 0 maka td warna kuning.
					echo"		
								<td style=\"border:1px solid #000; text-align:center\">$jenis_obat[id_obat]</td>
								<!--<td style=\"border:1px solid #000; text-align:center\">$jenis_obat[id_penyakit]</td>-->
								<td style=\"border:1px solid #000; text-align:center\">$jenis_obat[jenis_obat]</td>
								<td style=\"border:1px solid #000; text-align:center\">$jenis_obat[nama_obat]</td>
								<td style=\"border:1px solid #000; text-align:center\">$jenis_obat[persediaan]</td>
								<td style=\"border:1px solid #000; text-align:center\">$jenis_obat[tgl_masuk]</td>
								<td style=\"border:1px solid #000; text-align:center\">$jenis_obat[tgl_eks]</td>
								<td style=\"border:1px solid #000; text-align:center\">$jenis_obat[harga]</td>
								<td style=\"border:1px solid #000; text-align:center\">$jenis_obat[gambar]</td>
																
								<td style=\"border:1px solid #000; text-align:center;\">
								<a href='?adm=produk&proses=edit&id=$jenis_obat[id_obat]'>Edit</a> |
								<a href='?adm=produk&proses=delete&id=$jenis_obat[id_obat]'>delete</a></td>
							</tr>";
			$m++; //utk penambahan baris
				}
				
				}
		
		?>
</table>