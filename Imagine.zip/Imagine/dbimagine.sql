-- phpMyAdmin SQL Dump
-- version 3.4.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Waktu pembuatan: 21. April 2013 jam 15:20
-- Versi Server: 5.5.16
-- Versi PHP: 5.3.8

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dbimagine`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_absensi_trainer`
--

CREATE TABLE IF NOT EXISTS `tb_absensi_trainer` (
  `id_absensi` int(3) NOT NULL,
  `tanggal` date NOT NULL,
  `jam` time NOT NULL,
  `hari` date NOT NULL,
  `status_absensi` int(1) NOT NULL,
  PRIMARY KEY (`id_absensi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_jenis_kelas`
--

CREATE TABLE IF NOT EXISTS `tb_jenis_kelas` (
  `id_jenis_kelas` int(2) NOT NULL,
  `jenis_kelas` varchar(16) NOT NULL,
  PRIMARY KEY (`id_jenis_kelas`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_jenis_kelas`
--

INSERT INTO `tb_jenis_kelas` (`id_jenis_kelas`, `jenis_kelas`) VALUES
(1, 'reguler'),
(2, 'private'),
(3, 'studycase');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_karyawan`
--

CREATE TABLE IF NOT EXISTS `tb_karyawan` (
  `id_karyawan` int(3) NOT NULL,
  `nama_karyawan` varchar(32) NOT NULL,
  `phone_karyawan` varchar(15) NOT NULL,
  `email` varchar(32) NOT NULL,
  `id_person` int(2) NOT NULL,
  PRIMARY KEY (`id_karyawan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_karyawan`
--

INSERT INTO `tb_karyawan` (`id_karyawan`, `nama_karyawan`, `phone_karyawan`, `email`, `id_person`) VALUES
(0, '', '', '', 1),
(1, 'joko', '2147483647', 'joko@yahoo.com', 0),
(7, '', '', 'dfd@fdsf.com', 3),
(11, '', '', 'jacketkorea2013@gmail.com', 1),
(90, 'i', '09', '9', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_login`
--

CREATE TABLE IF NOT EXISTS `tb_login` (
  `level` int(2) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(6) NOT NULL,
  `status` varchar(10) NOT NULL,
  PRIMARY KEY (`level`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_login`
--

INSERT INTO `tb_login` (`level`, `username`, `password`, `status`) VALUES
(1, 'aku', '123456', 'Manager'),
(2, 'aku', '12345', 'FO'),
(3, 'aku', '1234', 'Keuangan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_person`
--

CREATE TABLE IF NOT EXISTS `tb_person` (
  `id_person` int(2) NOT NULL,
  `jenis_person` varchar(16) NOT NULL,
  PRIMARY KEY (`id_person`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_person`
--

INSERT INTO `tb_person` (`id_person`, `jenis_person`) VALUES
(1, 'calon siswa'),
(2, 'siswa'),
(3, 'trainer'),
(4, 'FO'),
(5, 'keuangan'),
(6, 'manager'),
(7, 'karyawan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_program`
--

CREATE TABLE IF NOT EXISTS `tb_program` (
  `id_program` int(3) NOT NULL,
  `nama_program` varchar(64) NOT NULL,
  `jumlah_sesi` int(2) NOT NULL,
  `id_jenis_kelas` int(2) NOT NULL,
  PRIMARY KEY (`id_program`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_program`
--

INSERT INTO `tb_program` (`id_program`, `nama_program`, `jumlah_sesi`, `id_jenis_kelas`) VALUES
(1, 'Android Academy', 10, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_siswa`
--

CREATE TABLE IF NOT EXISTS `tb_siswa` (
  `id_siswa` int(3) NOT NULL AUTO_INCREMENT,
  `nama_siswa` varchar(32) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `kampus` varchar(16) NOT NULL,
  `facebook` varchar(20) NOT NULL,
  `Kelas` varchar(15) NOT NULL,
  `tgl_daftar` date NOT NULL,
  `id_person` int(2) NOT NULL,
  `id_status` int(1) NOT NULL,
  PRIMARY KEY (`id_siswa`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=66 ;

--
-- Dumping data untuk tabel `tb_siswa`
--

INSERT INTO `tb_siswa` (`id_siswa`, `nama_siswa`, `phone`, `kampus`, `facebook`, `Kelas`, `tgl_daftar`, `id_person`, `id_status`) VALUES
(2, 'hanhinhun', '2323242', 'uin', '', '', '2013-04-03', 2, 2),
(3, 'jdjad', '99999', 'ds', '', '', '2013-03-22', 1, 2),
(4, 'aku', '908888', 'uii', '', '', '2013-03-22', 1, 0),
(9, 'indri cie', '8898989899', 'uin', '', '', '2013-04-09', 1, 0),
(36, 'face', '232', 'kk', '', '', '2013-04-13', 1, 0),
(37, '', '', '', '', '', '2013-04-13', 0, 0),
(38, '', '', '', '', '', '2013-04-13', 0, 0),
(39, '', '', '', '', '', '2013-04-13', 0, 0),
(40, '', '', '', '', '', '2013-04-13', 0, 0),
(41, 'qq', '23', 'ii', 'dfsdfdf', 'android', '2013-04-13', 2, 0),
(42, '', '', '', '', '', '2013-04-13', 0, 0),
(43, '', '', '', '', '', '2013-04-13', 0, 0),
(44, '', '', '', '', '', '2013-04-13', 0, 0),
(45, '', '', '', '', '', '2013-04-13', 0, 0),
(46, '', '', '', '', '', '2013-04-13', 0, 0),
(47, 'ain', '099', 'uii', 'kiki', 'android', '2013-04-20', 1, 0),
(48, '', '', '', '', '', '2013-04-20', 0, 0),
(49, '', '', '', '', '', '2013-04-20', 0, 0),
(50, '', '', '', '', '', '2013-04-20', 0, 0),
(51, '', '', '', '', '', '2013-04-20', 0, 0),
(52, '', '', '', '', '', '2013-04-20', 0, 0),
(53, '', '', '', '', '', '2013-04-20', 0, 0),
(54, '', '', '', '', '', '2013-04-20', 0, 0),
(55, '', '', '', '', '', '2013-04-20', 0, 0),
(56, '', '', '', '', '', '2013-04-20', 0, 0),
(57, '', '', '', '', '', '2013-04-20', 0, 0),
(58, '', '', '', '', '', '2013-04-20', 0, 0),
(59, '', '', '', '', '', '2013-04-20', 0, 0),
(60, '', '', '', '', '', '2013-04-20', 0, 0),
(61, '', '', '', '', '', '2013-04-20', 0, 0),
(62, 'ioio', '8769870', 'uii', 'aku', 'koko', '2013-04-20', 1, 0),
(63, '', '', '', '', '', '2013-04-20', 0, 0),
(64, '', '', '', '', '', '2013-04-20', 0, 0),
(65, 'ain', '098765', 'uii', 'aku', 'android', '2013-04-20', 1, 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_status`
--

CREATE TABLE IF NOT EXISTS `tb_status` (
  `id_status` int(1) NOT NULL,
  `status` varchar(12) NOT NULL,
  PRIMARY KEY (`id_status`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_status`
--

INSERT INTO `tb_status` (`id_status`, `status`) VALUES
(1, 'Aktif'),
(2, 'Tidak Aktif');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_trainer`
--

CREATE TABLE IF NOT EXISTS `tb_trainer` (
  `id_trainer` int(3) NOT NULL,
  `nama_trainer` varchar(32) NOT NULL,
  `phone_trainer` varchar(13) NOT NULL,
  `email_trainer` varchar(25) NOT NULL,
  PRIMARY KEY (`id_trainer`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
