<?php
	 include_once("C:/xampp/htdocs/fix/koneksi/koneksi.php");

?>
<form action="" method="post">	
				<td><select  onchange="this.form.submit()" name="tgl_daftar" >
							<?php

							$artikel=mysql_query("select distinct tgl_daftar from tb_siswa");

while ($baris=mysql_fetch_array($artikel)){

	list($year ,$month, $day) = explode('-', implode ($baris));
	$baris2=substr($year,0,4); 
	/**$baris1=substr($month,0,2);  
	if ($baris1==01)
	{ 
	$bulan="Januari";
	}
	else if ($baris1==02)
	{
	$bulan="Februari";
	}
	else if ($baris1==03)
	{
	$bulan="Maret";
	}
	else if ($baris1==04)
	{
	$bulan="April";
	}
	else if ($baris1==05)
	{
	$bulan="Mei";
	}
	else if ($baris1==06)
	{
	$bulan="Juni";
	}
	else if ($baris1==07)
	{
	$bulan="Juli";
	}
	else if ($baris1==08)
	{
	$bulan="Agustus";
	}
	else if ($baris1==09)
	{
	$bulan="September";
	}
	else if ($baris1==10)
	{
	$bulan="Oktober";
	}
	else if ($baris1==11)
	{
	$bulan="November";
	}
	else { 
	$bulan="Desember";
	} **/

echo "<option value=\"$baris2\">$baris2</option>";	
										}
							?> 
							

							</select></td>
							</form>