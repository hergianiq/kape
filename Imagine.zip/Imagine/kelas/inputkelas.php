<?php
 include_once("../koneksi/koneksi.php");
	
	 $id = $_POST['id_program']; 
	 $nama = $_POST['nama_program'];
     $jumlah_sesi = $_POST['jumlah_sesi'];
     $harga = $_POST['harga'];
		$id_karyawan = $_POST['id_karyawan'];
		$idjk = $_POST['id_jenis_kelas'];
	
                 
$query = mysql_query("insert into tb_program (id_program,nama_program,jumlah_sesi, harga,id_karyawan,id_jenis_kelas) 
values('$id','$nama','$jumlah_sesi','$harga','$id_karyawan','$idjk')") or die (mysql_error());
if ($query){
	
	echo" <script>
 document.location='?v=kelas'; return true; </script>";
	//header('location:?link=home');
}else{
	echo"<script>document.location='?v=forminputkelas';</script>";
}
?>

