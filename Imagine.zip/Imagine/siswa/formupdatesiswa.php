<script src="js/jquery.js"></script>
<script src="js/jquery.validate.js"></script>
<script type="text/javascript">
$(document).ready(function(){

});
</script>
<script type="text/javascript">
   function save(){
        /* ambil data dari form */
         $.ajax({
  url: 'siswa/prosesupdate.php',
  type: "POST",
  success: function(){
    alert('Failure');
  },
  error: function(){
    alert('Succes');
  }
});
   }
   </script>
<?php
		$id_siswa = addslashes($_GET['id_siswa']);
		$query = mysql_query("select a.id_siswa, a.nama_siswa, a.phone,a.id_status, a.kampus, a.facebook, a.id_person,
	  	a.tgl_daftar, b.jenis_person, c.nama_program, d.status from tb_siswa a, tb_person b, tb_program c, tb_status d where a.id_siswa='$id_siswa'
	  and a.id_person=b.id_person and a.id_program=c.id_program and a.id_status=d.id_status ") or die(mysql_error());
		$data = mysql_fetch_array($query);
		?>
  <a href="?v=adminsiswa">| Back |</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <!--  <img class="imgr" src="images/demo/tkd.jpg" alt="" width="125" height="125" /> -->
        <p align="center"> </p>
 
		<h3><p align="center">Edit Data siswa</p></h3>
		<form align="center" name="form1" method="post" action="siswa/prosesupdate.php">
		<input type="hidden" name="id_siswa" value="<?php echo $id_siswa; ?>" />
	       <table>
		<tr><td>Nama Siswa</td> <td><input type="text" name="nama_siswa" size="20" value="<?php echo $data['nama_siswa'];?>"></td></tr>
		<tr><td>Phone</td><td><input type="text" name="phone" size="20" value="<?php echo $data['phone'];?>"></td></tr>
		<tr><td>Facebook</td><td><input type="text" name="facebook" size="20" value="<?php echo $data['facebook'];?>"></td></tr>
		<tr><td>Kampus</td><td><input type="text" name="kampus" size="20" value="<?php echo $data['kampus'];?>"></td></tr>
		<tr><td>Tanggal Daftar</td><td><input type="text" name="tgl_daftar" size="20" value="<?php echo $data['tgl_daftar'];?>"></td></tr>
				
		<tr><td>Kelas</td><td><select  name="id_program"  >
				<option value="<?php echo $data['id_program'];?>"><?php echo $data['nama_program'];?></option>
							
							<?php
							$person=mysql_query("SELECT * FROM tb_program ");
								while($a=mysql_fetch_array($person)){
									echo "<option value=\"$a[id_program]\">$a[nama_program]</option>";		
									}
							?>
					</select></td></tr>
		
		<tr><td>Status</td>
		<td><SELECT name="id_person" >
			<option value="<?php echo $data['id_person'];?>"><?php echo $data['jenis_person'];?></option>
		<?php

		$person=mysql_query("SELECT * FROM tb_person where id_person=1 || id_person=2");
		while($data=mysql_fetch_array($person)){
		echo "<option value=\"$data[id_person]\">$data[jenis_person]</option>";
		}
		?>
		</select></td></TR>
		<tr><td></td>
			<td><input value="SAVE" name="submit" type="submit" onclick="save()"/> 
				<input value="RESET" type="reset" />
				<input value="BACK" type="button"  onClick="self.history.back()">
			</td>
		</tr>
        </table>