<?php

 include_once("koneksi/koneksi.php"); 

	
		$id= $_GET['id_program']; 	
$query = mysql_query("delete from tb_program where id_program='$id'") or die (mysql_error());

if($query){
	echo "<script>
	 
		  document.location='?v=kelas';
		  	  return true;
   </script>";
}else{
echo "<script>alert('Delete Failed');document.location='?v=kelas';</script>";
}
?>
