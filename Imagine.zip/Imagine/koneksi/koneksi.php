<?php
	mysql_connect("localhost","root","") or die ("Koneksi Gagal Coy");
	mysql_select_db("dbimagine") or die ("database kagak ada!");
?>