<?php

 include_once("../koneksi/koneksi.php");
  
	$id_karyawan = $_POST ['id_karyawan'];
     $nama_karyawan = $_POST['nama_karyawan'];
     $phone = $_POST['phone_karyawan'];
     $email = $_POST['email'];    
	 $idperson = $_POST['id_person'];
                 
$query = mysql_query("UPDATE tb_karyawan SET nama_karyawan='$nama_karyawan',phone_karyawan='$phone',email='$email', id_person='$idperson' WHERE id_karyawan='$id_karyawan'") or die (mysql_error());
if($query){
echo "<script>document.location='../index.php?v=adminkaryawan';</script>";
}else{
echo "<script>document.location='../?v=updatekaryawan';</script>";
}
?>