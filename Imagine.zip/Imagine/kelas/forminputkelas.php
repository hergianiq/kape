  <?php

 include_once("koneksi/koneksi.php");
   ?>
   <a href="?v=kelas">| Back |</a>
					

			<h2 align='center'><br>INPUT KELAS</h2><br><br>
			
			
			<form id="formku" name="fomr1" method="post" action="?v=inputkelas"/>		
		<table>
							<tr><td><input type="hidden" name="id_program" class="required"/></td></tr>
							<tr><td>Nama Program</td><td><input type="text" name="nama_program" class="required" ></td></tr>
						
					<tr><td>Jenis Kelas</td><td><select  name="id_jenis_kelas" >
							<?php

							$person=mysql_query("SELECT * FROM tb_jenis_kelas ");
								while($data=mysql_fetch_array($person)){
									echo "<option value=\"$data[id_jenis_kelas]\">$data[jenis_kelas]</option>";		}
							?>
					</select></td></tr>
							<tr><td>Jumlah Sesi</td><td><input type="text" name="jumlah_sesi" class="required" ></td></tr>
							<tr><td>Harga</td><td><input type="text" name="harga" class="required" ></td></tr>
							<tr><td>Trainer</td><td>
							
							<SELECT name="id_karyawan">
							
							<?php

							$person=mysql_query("SELECT * FROM tb_karyawan where id_person='3'");
								while($data=mysql_fetch_array($person)){
									echo "<option value=\"$data[id_karyawan]\">$data[nama_karyawan]</option>";		}
							?></select></td></tr>
							<tr><td><input value="Save" name="Save" type="submit" onclick="save()"/></td>
								<td><input value="Reset" type="reset" /></td></tr>
							
					</table>
					</form>	</br>
				<center>
								</center>
							
		