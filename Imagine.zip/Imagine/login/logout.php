<?php
//open session
session_start();

//penghapusan SESSION
unset($_SESSION['username']);
unset($_SESSION['password']);
unset($_SESSION['status']);
//unset($_SESSION['']);
session_destroy();
//pengalihan lokasi
header("location:index.php");

?>