			<center>	<br><br><br>
				<tr><a href="?v=loginmanager"><img src="gambar/manager.png" title="Manager" height="130" width="100" ></td></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<td><a href="?v=loginfo"><img src="gambar/fo.jpg" title="Front office" height="130" width="100"></td></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<td><a href="?v=loginkeu"><img src="gambar/keuangan.jpg" title="Keuangan" height="130" width="120"></td></a>
				</tr>		</br>
			<tr>
				<td><Font size=4 color="#5A5C5C">Manager</font></td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<td><Font size=4 color="#5A5C5C">Front Office</font></td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				<td><Font size=4  color="#5A5C5C">Keuangan</font></td>
				</tr>
			</center>