<?php
 include_once("../koneksi/koneksi.php");
	
	 $id_siswa = $_POST['id_siswa'];
     $nama=$_POST['nama_siswa'];
     $phone = $_POST['phone'];
     $kampus = $_POST['kampus'];
	 $face = $_POST['facebook'];
	 $id_program = $_POST['id_program'];
	 $tanggal= date("Y-m-d H:i:s");
	 $id_person=$_POST['id_person'];
                 
$query = mysql_query("insert into tb_siswa (id_siswa,nama_siswa,phone, kampus,facebook, id_program, tgl_daftar, id_person, id_status,id_pembayaran) 
values('$id_siswa','$nama','$phone','$kampus','$face','$id_program','$tanggal','$id_person', '1', '0')") or die (mysql_error());
if ($query){
	
	echo" <script>
 document.location='../?v=adminsiswa'; return true; </script>";
	//header('location:?link=home');
}else{
	echo"<script>document.location='../?v=forminputsiswa';</script>";
}
?>

