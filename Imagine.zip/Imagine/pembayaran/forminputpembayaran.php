<!doctype html>
 
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>jQuery UI Datepicker - Default functionality</title>
  <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />
  <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
  <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
  <link rel="stylesheet" href="/resources/demos/style.css" />
  <script>
  $(function() {
    $( "#datepicker" ).datepicker();
  });
  </script>



   <style type="text/css">
       label.error {
           color: red; padding-left: .5em;
       }
   </style>

	 
<script type="text/javascript">
$(document).ready(function(){

});
</script><script type="text/javascript">
   function save(){
        /* ambil data dari form */
         $.ajax({
  url: 'pembayaran/inputpembayaran.php',
  type: "POST",
  success: function(){
    alert('Failure');
  },
  error: function(){
    alert('Succes');
  }
});
   }
   </script></head>
<?php

 include_once("koneksi/koneksi.php");
   ?>
<script type="text/javascript">
$(document).ready(function(){

});
</script>
   <script type="text/javascript">
   function save(){
        /* ambil data dari form */
         $.ajax({
  url: 'pembayaran/inputpembayaran.php',
  type: "POST",
  success: function(){
    alert('Failure');
  },
  error: function(){
    alert('Succes');
  }
});
   }
   </script>
   <a href="?v=pembayaran">| Back |</a>
					

			<h2 align='center'><br>INPUT SISWA</h2><br><br>
			
			
			<form id="formku" name="fomr1" method="post" action="?v=inputpembayaran"/>		
		
					<table>
							
							<tr><td>Nama Siswa</td><td>							
							<SELECT name="id_siswa">
							<option value="">- Pilih Siswa -</option><?php
							$person=mysql_query("SELECT * FROM tb_siswa where id_status='1' and id_person='2' ");
								while($data=mysql_fetch_array($person)){
									echo "<option value=\"$data[id_siswa]\">$data[nama_siswa]</option>";		}
							?>								</select></td></tr>				
							<tr><td>Tanggal Daftar</td><td><input type="text" id="datepicker" name="tgl_bayar" ></td></tr>
						
							<tr><td>Status</td><td>							
							<SELECT name="id_pembayaran">
							<option value="">- Pilih Status Pembayaran -</option>
							<?php

							$person=mysql_query("SELECT * FROM tb_pembayaran ");
								while($data=mysql_fetch_array($person)){
									echo "<option value=\"$data[id_pembayaran]\">$data[status_pembayaran]</option>";		}
							?>
							
					</select></td></tr>
					<tr><td>Penerima</td><td>							
							<SELECT name="id_karyawan">
							<option value="">- Pilih Penerima -</option>
							<?php

							$person=mysql_query("SELECT nama_karyawan FROM tb_karyawan where id_person=4  ");
								while($data=mysql_fetch_array($person)){
									echo "<option value=\"$data[id_karyawan]\">$data[nama_karyawan]</option>";		}
							?>
							
					</select></td></tr>
							
							<tr><td><input value="Save" name="Save" type="submit" onclick="save()"/></td>
								<td><input value="Reset" type="reset" /></td></tr>
							
					</table>
					</form>	</br>
				<center>
								</center>
							