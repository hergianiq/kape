<?php


 include_once("../koneksi/koneksi.php");
  
	
		 $id_program = $_POST['id_program'];
		 $nama = $_POST['nama_program'];
		$id_jenis= $_POST['id_jenis_kelas'];		 
		 $id_kary = $_POST['id_karyawan'];	
		 $jum =$_POST['jumlah_sesi'];		
		 $harga =$_POST['harga'];
                 
$query = mysql_query("update tb_program set nama_program='$nama', id_jenis_kelas='$id_jenis', id_karyawan='$id_kary', harga='$harga', jumlah_sesi='$jum' where id_program='$id_program'") or die (mysql_error());
if($query){
echo "<script>document.location='?v=kelas';</script>";
}else{
echo "<script>document.location='../index.php?v=forminputkelas';</script>";
}
?>