							<?php
	 include_once("C:/xampp/htdocs/fix/koneksi/koneksi.php");

?>
<form action="" method="post">	
				<td><select  onchange="this.form.submit()" name="tgl_daftar" >
							<?php

							$artikel=mysql_query("select distinct tgl_daftar from tb_siswa");

while ($baris=mysql_fetch_array($artikel)){

	list($year ,$month, $day) = explode('-', implode ($baris));
	$baris2=substr($year,0,4); 
	

echo "<option value=\"$baris2\">$baris2</option>";	
										}
							?> 
							

							</select></td>
							</form>

							