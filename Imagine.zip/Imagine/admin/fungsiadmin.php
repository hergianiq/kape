<?php
function sesiadmin(){

session_start();
if(!isset($_SESSION['username']) || !isset($_SESSION['passwdord']));
}
?>
