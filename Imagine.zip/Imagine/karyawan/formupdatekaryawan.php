
 <link rel="stylesheet" type="text/css" href="css/style.css"/>
  <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.2/themes/smoothness/jquery-ui.css" />
  <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
  <script src="http://code.jquery.com/ui/1.10.2/jquery-ui.js"></script>
  <link rel="stylesheet" href="/resources/demos/style.css" />

  <style type="text/css">
       label.error {
           color: red; padding-left: .5em;
       }
   </style>
   
  <script src="js/jquery.js"></script>
  <script src="js/jquery.validate.js"></script>
  <script>
       $(document).ready(function(){
           $("#formku").validate();
        });
   </script>
<script type="text/javascript">
$(document).ready(function(){

});
</script><script type="text/javascript">
   function save(){
        /* ambil data dari form */
         $.ajax({
   url: 'karyawan/inputkaryawan.php',
  type: "POST",
  success: function(){
    alert('Gagal.. - Lengkapi Field yang kosong..');
  },
  error: function(){
    alert('Succes');
  }
});
   }
   </script>
</head>




<?php
	 include_once("koneksi/koneksi.php");
	//include ("koneksi/koneksi.php");

		$id_karyawan = $_GET['id_karyawan'];
		$query = mysql_query("select * from tb_karyawan where id_karyawan='$id_karyawan'") or die(mysql_error());
		$data = mysql_fetch_array($query);
		?>
		<tr><td><a href="?v=adminkaryawan">| Back |</td></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  
      <!--  <img class="imgr" src="images/demo/tkd.jpg" alt="" width="125" height="125" /> -->
        
		<h3><p align="center">Edit Data Karyawan</p></h3>
		<form name="form1"id="formku" method="post" action="karyawan/prosesupdatekaryawan.php">
		<input type="hidden" name="id_karyawan" value="<?php echo $id_karyawan; ?>" />

		<table>
		<tr><td>Nama karyawan</td> <td><input type="text" name="nama_karyawan" class="required" size="30" value="<?php echo $data['nama_karyawan'];?>"></td></tr>
		<tr><td>Phone</td><td><input type="text" name="phone_karyawan" size="30" class="required digits" value="<?php echo $data['phone_karyawan'];?>"></td></tr>
		<tr><td>Email</td><td><input type="text" name="email" size="30" class="required email" value="<?php echo $data['email'];?>"></td></tr>
		<tr><td>Status</td>
		<td><SELECT name="id_person">
		
		<?php

		$person=mysql_query("SELECT * FROM tb_person where id_person=3 || id_person=4|| id_person=5|| id_person=6|| id_person=7");
		while($data=mysql_fetch_array($person)){
		echo "<option value=\"$data[id_person]\">$data[jenis_person]</option>";
		}
		?>
		</select></td></TR>
		<tr><td></td>
			<td><input value="SAVE" name="submit" type="submit" onclick="save()"/> 
				<input value="RESET" type="reset" />
				<input value="BACK" type="button"  onClick="self.history.back()">
			</td>
		</tr>
        </table>