<!--
<tr>
<td><a href="?v=forminputsiswa"><img src="gambar/add.jpg" title="Input Siswa" height="30" width="25"></td></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<td><a href="?v=updatesiswa"><img src="gambar/edit.ico" title="Edit Siswa" height="30" width="25"></td></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<td><a href="?v=deletesiswa"><img src="gambar/delete.png" title="Edit Siswa" height="30" width="25"></td></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</tr></br>-->
<tr><td><a href="?v=adminsiswa">| Back |</td></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<a href="?v=forminputsiswa" align="left">| Input Siswa |</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
	
		
		<h2 align='center'><br>Daftar Nama Siswa</h2><br>
			<table>
		<tr>
				<td>
					Kelas :</td>
				<form action="?v=class" method="post">	
				<td><select  onchange="this.form.submit()" name="id_program" >
							<option value="">- Search -</option>
							<option value="all">All</option>
							<?php

							$person=mysql_query("SELECT * FROM tb_program ");
								while($data=mysql_fetch_array($person)){
									echo "<option value=\"$data[id_program]\">$data[nama_program]</option>";		}
							?>
					</select></td>
			
					</form>
				</td>
					<td>
					<form action="?v=search" method="post">
						<input type="text" name="search" placeholder="Pencarian"/>
						
					</form> 
					</td>
			</tr>
			</table></br>  
				 <table width="100%" cellpadding="2" border="1">
         <?php
include "koneksi/koneksi.php";
	if(isset($_GET['a'])){
		$cr=addslashes($_GET['search']);
	}else{
		$cr=addslashes($_POST['search']);
	}
	$cari=preg_replace("/\s/","%",$cr);
	if($cari==''){ echo " Not Found 
	"; 
	}
 
	else{
		?>
		
		  
				<?php 
					$artikel=mysql_query("select a.id_siswa, a.nama_siswa, a.phone, a.kampus, a.facebook, a.tgl_daftar, b.jenis_person, c.nama_program, d.status from tb_siswa a,tb_person b, tb_program c, tb_status d where a.id_person=b.id_person and a.id_program=c.id_program and a.id_status=d.id_status and a. id_status='1' and nama_siswa  LIKE '%$cari%' ORDER BY id_siswa DESC;");
							$ja=mysql_num_rows($artikel);
						
if ($ja==0) {
echo "<h2 align='center'><br>Tidak Ditemukan</h2><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>";
}

			
else {					
					echo'<th  style="background:#5A5C5C"><font color="#ffffff" width="3">No</font></th>
				   <th  style="background:#5A5C5C"><font color="#ffffff">Nama</font></th>
						<th  style="background:#5A5C5C"><font color="#ffffff">Phone</font></th>
					  <th  style="background:#5A5C5C"><font color="#ffffff">Kampus</font></th>
  				   <th  style="background:#5A5C5C"><font color="#ffffff">Kelas</font></th>
				    <th  style="background:#5A5C5C"><font color="#ffffff">Facebook</font></th>
				<th  style="background:#5A5C5C"><font color="#ffffff">Tanggal Daftar</font></th>
			   <th  style="background:#5A5C5C"><font color="#ffffff">Status</font></th>;
		   <th  style="background:#5A5C5C"><font color="#ffffff">Action</font></th>';
		
	
		     $nomor=1;
		   while($data=mysql_fetch_array($artikel))		  
		   {
		   		if(($nomor % 2)== 0){
		   			$bgcolor="#F7D891";
			}else{
				$bgcolor="#F7F6DE";
			}
				$nama= $data['id_siswa'];
		   ?>
                     <tbody>
			<tr bgcolor="<?php echo $bgcolor;?>";>
			 <td ><?php echo" $nomor"?></td>
			 <td><?php echo" $data[nama_siswa]"?></td>
			  <td><?php echo" $data[phone]"?></td>
			  <td ><?php echo" $data[kampus]"?></td>
			  		  <td><?php echo" $data[nama_program]"?></td>
			  <td><?php echo" $data[facebook]"?></td>
						  <td ><?php echo" $data[tgl_daftar]"?></td>
			  <td><?php echo" $data[jenis_person]"?></td>
			 <td> <a href="?v=updatesiswa&id_siswa=<?php echo "$nama"?>"><b>Edit</b></a> | 
		<a href="?v=prosesdelete&id_siswa=<?php echo "$nama"?>"><b>Delete</b></a></td>
            </tr>
		
			<?php 
			$nomor++; 
			}
			
			?>
          </tbody>
        <?php echo "</table>"?>	  
			 
			<?php } }?>
								

				