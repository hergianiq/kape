<script type="text/javascript">
$(document).ready(function(){

});
</script>
<script type="text/javascript">
   function save(){
        /* ambil data dari form */
         $.ajax({
  url: 'kelas/inputkelas.php',
  type: "POST",
  success: function(){
    alert('Failure');
  },
  error: function(){
    alert('Succes');
  }
});
   }
   </script> 
 <?php

 include_once("koneksi/koneksi.php");
   ?>
   <a href="?v=absensi">| Back |</a></br>
				 <?php
	  $sql=mysql_query("select a.id_absensi, a.id_siswa, a.id_program, a.jumlah_hadir, a.jumlah_izin, a.jumlah_sakit, a.update, c.nama_siswa, d.nama_program
from tb_absensi a, tb_siswa c, tb_program d where a.id_siswa=c.id_siswa and a.id_program=d.id_program ");
 
  ?>	

			<h2 align='center'><br>UPDATE ABSENSI SISWA</h2><br><br>
			
			
			
								
		 <table border="0" style="color:#000;" bgcolor="#000" width="100%" cellpadding="2" cellspacing="1">
          
		  <tr>
			<th  align="center" style="background:#5A5C5C" width="3%" rowspan=2><font color="#ffffff"  >NO</font></th>
			<th  align="center" style="background:#5A5C5C" width="14%" rowspan=2><font color="#ffffff" >Nama Siswa</font></th>
			<th  align="center" style="background:#5A5C5C" width="10%"colspan=3><font color="#ffffff">Keterangan</font>
			
			</tr>
		 <tr>
		 <th  align="center" style="background:#5A5C5C" width="10%"><font color="#ffffff">Hadir</font></th>
			<th  align="center" style="background:#5A5C5C" width="15%"><font color="#ffffff">Sakit</font></th>
			<th  align="center" style="background:#5A5C5C" width="10%"><font color="#ffffff">Izin</font></th>
			 </tr>
		
	<?php
		   $nomor=1;
		   while($data=mysql_fetch_array($sql))		  
		   {
		   		if(($nomor % 2)== 0){
		   			$bgcolor="#F7D891";
			}else{
				$bgcolor="#F7F6DE";
			}
				$nama= $data['id_program'];
		   ?>
             <form id="formku" name="fomr1" method="post" action=""/>	   
			<tr bgcolor="<?php echo $bgcolor;?>";>
			<td align="center" ><?php echo" $nomor"?></td>
			<td ><?php echo" $data[nama_siswa]"?></td>
				
		
							<input type="hidden" name="id_absensi" class="required"/>
							<td align="center" ><input type="checkbox" name="jumlah_hadir" value="jumlah_hadir"> <br>	</td>		
							<td align="center" ><input type="checkbox" name="jumlah_izin" value="jumlah_izin"> <br>	</td>		
							<td align="center" ><input type="checkbox" name="jumlah_sakit" value="jumlah_sakit"> <br>	</td>						
					 </tr>
					
			
			
			
			
		
		
			<?php 
			$nomor++; 
			}
			
			?>
			   <?php echo "</table>"?></br></br></br></br>
      <tr><td><input value="Save" name="Save" type="submit" onclick="save()"/></td></tr>
								
           </form>	</br>
     