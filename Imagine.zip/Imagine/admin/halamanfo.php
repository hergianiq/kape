<!DOCTYPE html PUBLIC "-//W3C//Dth XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/Dth/xhtml1-transitional.dth">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="author" content="realitysoftware.ca" />
<title></title>
<link rel="stylesheet" type="text/css" href="css/style.css"/>

</head>
<?php
session_start ();
include ("koneksi.php");
include ("fungsiadmin.php");
//sesiadmin();
?>

 <?php
	  $sql=mysql_query("select tb_siswa.id_siswa, tb_siswa.nama_siswa, tb_siswa.phone, tb_siswa.kampus,tb_siswa.tgl_daftar, tb_person.jenis_person from tb_siswa inner join tb_person on tb_siswa.id_person=tb_person.id_person");
	  ?>
<body>

<div id="container">

			<div id="header">
			<a href="@"><img src="../gambar/imagine11.jpg" width="600" height="120" title="Imagine IT Center"></a>
			</div>

			<div id="menu">
			<h1><center><FONT COLOR="#FFF"> WELCOME </FONT></h1></center>
			</div>

<!--			<div id="sidebar">
									
			</div>
-->
			<div id="main">
			<br><br><h2 align='center'><br>Menu Siswa</h2><br><br>
			

			<p align="left">
			<table cellpadding="0" cellspacing="0">
          <thead>
      
		  <tr>
			  <th rowspan=2>No</th>
			   <th>Id Siswa</th>
              <th>Nama Siswa</th>
              <th>Phone Siswa</th>
			  <th>Kampus</th>
			  <th>Tanggal Daftar</th>
			
            </tr>
			</thead>
				   <?php
		   $nomor=1;
		   while($data=mysql_fetch_array($sql))		  
		   {
				$id= $data['id_siswa'];
		   ?>
           <tbody>
			<tr>
			 <th ><?php echo" $nomor"?></th>
			  <th ><?php echo" $data[id_siswa]"?></th>
			  <th><?php echo" $data[nama_siswa]"?></th>
			  <th><?php echo" $data[phone]"?></th>
			  <th ><?php echo" $data[kampus]"?></th>
			    <th ><?php echo" $data[tgl_daftar]"?></th>
			  <th><?php echo" $data[jenis_person]"?></th>
			 
            </tr>
		
			<?php 
			$nomor++; 
			}
			?>
			
          </tbody>
        </table>
			</p>	
			</div>
		
		<p align="left"><a href="forminputsiswa.php">Tambah Data</a></p>
			</div>

			<div id="footer">
			&copy;Imagine IT Center &nbsp;<span class="separator">|</span>&nbsp; Design by 
			<a href="http://www.realitysoftware.ca" title="Website Design">Imagine</a>
			</div>

</div>

</body>
</html>

                       
                
