<script src="js/jquery.js"></script>
<script src="js/jquery.validate.js"></script>
<script type="text/javascript">
$(document).ready(function(){

});
</script>
<script type="text/javascript">
   function save(){
        /* ambil data dari form */
         $.ajax({
  url: 'siswa/prosesupdate.php',
  type: "POST",
  success: function(){
    alert('Failure');
  },
  error: function(){
    alert('Succes');
  }
});
   }
   </script>
<?php
		$id = addslashes($_GET['id_bayar']);
		$query = mysql_query("select a.id_siswa,a.nama_siswa, c.nama_program, c.harga,d.jenis_kelas,b.id_pembayaran, b.status_pembayaran, e.tgl_bayar, e.id_siswa,c.id_program, e.id_karyawan, f.nama_karyawan from tb_siswa a, tb_pembayaran b, tb_program c, tb_jenis_kelas d, tb_karyawan f, tb_bayar e 
	  where e.id_bayar='$id' and b.id_pembayaran=e.id_pembayaran and a.id_program=c.id_program and d.id_jenis_kelas=c.id_jenis_kelas and f.id_karyawan=e.id_karyawan and a.id_siswa=e.id_siswa") or die(mysql_error());
		$data = mysql_fetch_array($query);
		?>
  <tr><td><a href="index.php?v=pembayaran">| Back |</td></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <!--  <img class="imgr" src="images/demo/tkd.jpg" alt="" width="125" height="125" /> -->
        <p align="center"> </p>
        <table>
		<h3><p align="center">Edit Data siswa</p></h3>
		<form name="form1" method="post" action="?v=updatepembayaran">
		<input type="hidden" name="id_bayar" value="<?php echo $id; ?>" />
		
		<table>
		<tr><td>Nama Siswa       </td><td><?php echo $data['nama_siswa'];?></td></tr>
		<tr><td>Kelas            </td><td><?php echo $data['nama_program'];?></td></tr>
		<tr><td>Jenis Kelas      </td><td><?php echo $data['jenis_kelas'];?></td></tr>		
		<tr><td>Tanggal Bayar   </td><td><input type="text" name="tgl_bayar" value="<?php echo $data['tgl_bayar']; ?>" /></td></tr>
		<tr><td>Update Status Pembayaran</td>
		<td><SELECT name="id_pembayaran"/>
							<option value="<?php echo $data['id_pembayaran'];?>"><?php echo $data['status_pembayaran'];?></option>
							<?php

							$person=mysql_query("SELECT * FROM tb_pembayaran ");
								while($a=mysql_fetch_array($person)){
									echo "<option value=\"$a[id_pembayaran]\">$a[status_pembayaran]</option>";	
									}
							?>
					</select></td></tr>
					<tr><td>Update Penerima</td>
		<td><SELECT name="id_karyawan"/>
							<option value="<?php echo $data['id_karyawan'];?>"><?php echo $data['nama_karyawan'];?></option>
							<?php

							$person=mysql_query("SELECT * FROM tb_karyawan where id_person='4' ");
								while($data=mysql_fetch_array($person)){
									echo "<option value=\"$data[id_karyawan]\">$data[nama_karyawan]</option>";	
									}
							?>
					</select></td></tr>
				
		
		
				<td><input value="SAVE" name="submit" type="submit" onclick="save()"/> 
			
				<input value="BACK" type="button"  onClick="self.history.back()">
			</td>
		</tr>
        </table>