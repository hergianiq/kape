<?php
include "koneksi/koneksi.php";
	if(isset($_GET['data'])){
		$cr=addslashes($_GET['id_program']);
	}else{
		$cr=addslashes($_POST['id_program']);
	}
	$cari=preg_replace("/\s/","%",$cr);
	if($cari==''){ echo " Not Found 
	"; 
	}
 
	else{
		?>
		
<tr><td><a href="?v=absensi">| Back |</td></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<a href="?v=forminputabsensi" align="left">| Input Absensi |</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		
		
		<h2 align='center'><br>Absensi Siswa</h2><br>
			<table>
			<tr>
				<td>
					Kelas :</td>
				<form action="" method="post">	
				<td><select  onchange="this.form.submit()" name="id_program" >
							<option value="">- Search -</option>
							
							<?php

							$person=mysql_query("SELECT * FROM tb_program ");
								while($data=mysql_fetch_array($person)){
									echo "<option value=\"$data[id_program]\">$data[nama_program]</option>";		}
							?> 
							

							</select></td>
							<?php if ($cari=="") {
							$a="";
							}
							else {
							$person=mysql_query("SELECT nama_program FROM tb_program  where id_program='$cari'");
							while ($data=mysql_fetch_array($person))
							{
							$a=$data['nama_program'];	
							}
							
									}
							
							?>
			<td><?php echo "$a";?></td>
				
					</form>
				</td>
					
			</tr>
			</table></br>  
				 <table width="100%" cellpadding="2" border="1">
        	<?php  if ($cari=="$cari")
						
			 {
$artikel=mysql_query("select a.id_absensi, a.id_siswa, a.id_program, a.jumlah_hadir, a.jumlah_izin, a.jumlah_sakit, a.update, c.nama_siswa, d.nama_program
from tb_absensi a, tb_siswa c, tb_program d where a.id_siswa=c.id_siswa and a.id_program=d.id_program and a.id_program like '%$cari%'");

$ja=mysql_num_rows($artikel);
						
if ($ja==0) {
echo "<h2 align='center'><br></h2>


<br><br><br><br><br><br><br><br><br><br><br><br><br><br>";
}

			
else {				echo'
			<table border="0" style="color:#000;" bgcolor="#000" width="100%" cellpadding="2" cellspacing="1"><tr>
			<th  align="center" style="background:#5A5C5C" width="3%" rowspan=2><font color="#ffffff"  >NO</font></th>
			<th  align="center" style="background:#5A5C5C" width="14%" rowspan=2><font color="#ffffff" >Nama Siswa</font></th>
			<th  align="center" style="background:#5A5C5C" width="10%"colspan=3><font color="#ffffff">Keterangan</font>
			<th  align="center" style="background:#5A5C5C" width="10%" rowspan=2><font color="#ffffff">Update</font></th>
			<th  align="center" style="background:#5A5C5C" width="10%" rowspan=2><font color="#ffffff">Action</font></th>
			</tr>
		 <tr>
		 <th  align="center" style="background:#5A5C5C" width="10%"><font color="#ffffff">Hadir</font></th>
			<th  align="center" style="background:#5A5C5C" width="15%"><font color="#ffffff">Sakit</font></th>
			<th  align="center" style="background:#5A5C5C" width="10%"><font color="#ffffff">Izin</font></th>
			 </tr> ';
		
	
		     $nomor=1;
		   while($data=mysql_fetch_array($artikel))		  
		   {
		   
		   		if(($nomor % 2)== 0){
		   			$bgcolor="#F7D891";
			}else{
				$bgcolor="#F7F6DE";
			}
				$nama= $data['id_program'];
		   ?>
                     <tbody>
			<tr bgcolor="<?php echo $bgcolor;?>";>
			<td align="center" ><?php echo" $nomor"?></td>
			<td ><?php echo" $data[nama_siswa]"?></td>
			<td align="center" ><?php echo" $data[jumlah_hadir]"?></td>
			<td align="center" ><?php echo" $data[jumlah_izin]"?></td>
			<td align="center" ><?php echo" $data[jumlah_sakit]"?></td>
			<td align="center" ><?php echo" $data[update]"?></td>
			 <td align="center" > <a href="?v=updatesiswa&id_siswa=<?php echo "$nama"?>"><font color="blue">Update</font></a> | 
		<a href="?v=prosesdelete&id_siswa=<?php echo "$nama"?>"><font color="red">Delete</font></a></td>
            </tr>
		
			<?php 
			$nomor++; 
			}
			
			?>
          </tbody>
        <?php echo "</table>"?>	  
           
	<?php } } 
	
	else {}
	}?>
				