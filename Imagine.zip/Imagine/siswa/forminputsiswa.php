<!doctype html>
 
<html lang="en">
<head>
  <meta charset="utf-8" />
  <title>jQuery UI Datepicker - Default functionality</title>
  <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />
  <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
  <script src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
  <link rel="stylesheet" href="/resources/demos/style.css" />
  <script>
  $(function() {
    $( "#datepicker" ).datepicker();
  });
  </script>


<script type="text/javascript">
$(document).ready(function(){

});
</script><script type="text/javascript">
   function save(){
        /* ambil data dari form */
         $.ajax({
  url: 'siswa/inputsiswa.php',
  type: "POST",
  success: function(){
    alert('Failure');
  },
  error: function(){
    alert('Succes');
  }
});
   }
   </script>
</head>
   <style type="text/css">
       label.error {
           color: red; padding-left: .5em;
       }
   </style>
  
	

  <?php

 include_once("koneksi/koneksi.php");
   ?>
   <a href="?v=adminsiswa">| Back |</a>
					

			<h2 align='center'><br>INPUT SISWA</h2><br><br>
			
			
			<form id="formku" name="fomr1" method="post" action="siswa/inputsiswa.php"/>		
		<table>
							<tr><td><input type="hidden" name="id_siswa" class="required"/></td></tr>
							<tr><td>Nama Siswa</td><td><input type="text" name="nama_siswa" class="required"/></td></tr>		
							<tr><td>Phone</td><td><input type="text" name="phone" class="required digits" ></td></tr>
							<tr><td>Kampus</td><td><input type="text" name="kampus" class="required" ></td></tr>
							<tr><td>Facebook</td><td><input type="text" name="facebook" class="required" ></td></tr>
							<tr><td>Kelas</td><td><select  name="id_program" >
							<?php

							$person=mysql_query("SELECT * FROM tb_program ");
								while($data=mysql_fetch_array($person)){
									echo "<option value=\"$data[id_program]\">$data[nama_program]</option>";		}
							?>
					</select></td></tr>
							<tr><td>Tanggal Daftar</td><td><input type="text" id="datepicker" name="tgl_daftar" class="required date"></td></tr>
							
							<tr><td>Id Person</td><td>
							<SELECT name="id_person">
							
							<?php

							$person=mysql_query("SELECT * FROM tb_person where id_person=1 || id_person=2");
								while($data=mysql_fetch_array($person)){
									echo "<option value=\"$data[id_person]\">$data[jenis_person]</option>";		}
							?></select></td></tr>
							<tr><td><input value="Save" name="Save" type="submit" onclick="save()"/></td>
								<td><input value="Reset" type="reset" /></td></tr>
							
					</table>
					</form>	</br>
				<center>
								</center>
							
		