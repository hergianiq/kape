<SCRIPT LANGUAGE="JavaScript">
function validate(){
x=document.form1

Fname2=x.nama_karyawan.value
if (Fname2.length==0)
 {
 alert("Nama  harus diisi.")
 return false
 submitOK="False"
 }
 
Lname3=x.id_karyawan.value
if (Lname3.length==0)
 {
 alert("Nama belakang tidak boleh kosong.")
 return false
 submitOK="False"
 }
 
var counter=0;
jk=x.jenis_kelamin.length;
for (i=0; i < jk; i++) {
if (x.jenis_kelamin[i].checked) counter++;
}

if(counter==0) {alert("Pilih salah satu gender.")
return false
submitOK="False"}

almt=x.alamat_lengkap.value
if (almt.length==0 || almt.length<10)
 {
 alert("Alamat harus lengkap.")
 return false
 submitOK="False"
 }
Phonenum=x.phone_karyawan.value
if (Phonenum.length==0)
 {
 alert("Nomor telepon tidak boleh kosong.")
  return false
 submitOK="False"
 }
job=x.pekerjaan.value
if (job.length==0)
 {
 alert("Isi form pekerjaan.")
  return false
 submitOK="False"
 }
  
for (var i=0; i < Phonenum.length; i++) {
    digitb = "" + Phonenum.substring(i, i+1);
    if (angka.indexOf(digitb) == "-1") {
        window.alert("Karakter pada No Telepon yang dimasukkan salah (harus angka semua)");
        return false;
    }
}
	var cek = x.getElementById(cek).value;     
	var regex = /^([A-Z] [A-Z][ A-Z][ A-Z])+\.+\.([1000-3000])$/;     
	if(cek == "" || regex.test(cek)==false)
	{
		alert(" tidak valid");   
			return false
			 submitOK="False"
	}
	   
 
if(submitOK=="False"){
  return false
  }
}
</SCRIPT>

   <a href="?v=adminkaryawan">| Back |</a>
   
</p><h2 align="center">Input Karyawan</h2><br>
		<form id="form1" name="form1" method="POST" action="karyawan/inputkaryawan.php">		
		<table>
	<tr><td>Id karyawan</td><td><input type="text" name="id_karyawan" class="digits"/></td></tr>
		<tr><td>Nama Karyawan</td><td><input type="text" name="nama_karyawan" class="required"/></td></tr>		
		<tr><td>No. Hp</td><td><input type="text" name="phone_karyawan" class="number"></td></tr>
		<tr><td>Email</td><td><input type="text" name="email" class="email"></td></tr>
		<tr><td><tr>
		<td>Id Person</td><td>
		<SELECT name="id_person">
		<?php 
		
 include_once("C:/xampp/htdocs/fix/koneksi/koneksi.php");


		$person=mysql_query("SELECT * FROM tb_person where id_person=3 || id_person=4|| id_person=5|| id_person=6 || id_person=7 ");
		while($data=mysql_fetch_array($person)){
		echo "<option value=\"$data[id_person]\">$data[jenis_person]</option>";
		}
		?>
		</select></td>
		</tr></td></tr>
				
        </table>		<input value="Save" name="submit" type="submit" class="submit"/> 
				<input value="Reset" type="reset" />
		</form></br>
			

				