<?php

	if(!isset($_GET['v'])){
		//require_once"admin/fo.php";
	}else if($_GET['v']=='logout'){
		require_once"login/logout.php";
	}else{
		//require_once"admin/fo.php";
	}

?>