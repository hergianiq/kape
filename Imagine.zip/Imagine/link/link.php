<?php
	if(!isset($_GET['v'])){								//isset v ini di gunakan jika tidak ada form yg di pilih.
		include "dasbord/dasbord.php";
	}else if($_GET['v']=='loginmanager'){				// jika variable v memanggila home --> maka akan memanggil content home dan juga selanjutnya. Variable V itu menggunakan method GET
		include "login/loginmanager.php";
	}else if($_GET['v']=='loginfo'){
		require_once "login/loginfo.php";
	}else if($_GET['v']=='loginkeu'){
		require_once "login/loginkeu.php";
	}else{
		include "dasbord/dasbord.php";
	}// jangan dilanjutkan else if
	
	
?>
