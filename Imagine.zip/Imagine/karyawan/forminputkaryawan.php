<link rel="stylesheet" type="text/css" href="css/style.css"/>
  <link rel="stylesheet" href="http://code.jquery.com/ui/1.10.2/themes/smoothness/jquery-ui.css" />
  <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
  <script src="http://code.jquery.com/ui/1.10.2/jquery-ui.js"></script>
  <link rel="stylesheet" href="/resources/demos/style.css" />

  
  <script src="js/jquery.js"></script>
  <script src="js/jquery.validate.js"></script>
  <script>
       $(document).ready(function(){
           $("#formku").validate();
        });
   </script>
<script type="text/javascript">
$(document).ready(function(){

});
</script><script type="text/javascript">
   function save(){
        /* ambil data dari form */
         $.ajax({
  url: 'karyawan/inputkaryawan.php',
  type: "POST",
  success: function(){
    alert('Gagal.. - Lengkapi Field yang kosong..');
  },
  error: function(){
    alert('Succes');
  }
});
   }
   </script>
</head>
   <style type="text/css">
       label.error {
           color: red; padding-left: .5em;
       }
   </style>
   <a href="?v=adminkaryawan">| Back |</a>
   
</p><h2 align="center">Input Karyawan</h2><br>
		<form id="formku" name="fomr1" method="post" action="karyawan/inputkaryawan.php"/>
		<table >
    <tr><td>Nama Karyawan</td><td><input type="text" name="nama_karyawan" class="required"/></td></tr>		
		<tr><td>No. Hp</td><td><input type="text" name="phone_karyawan" class="required digits"></td></tr>
		<tr><td>Email</td><td><input type="text" name="email" class="required email"></td></tr>
		<tr><td><tr>
		<td>Id Person</td><td>
		<SELECT name="id_person">
		<?php 
		
 include_once("C:/xampp/htdocs/fix/koneksi/koneksi.php");


		$person=mysql_query("SELECT * FROM tb_person where id_person=3 || id_person=4|| id_person=5|| id_person=6 || id_person=7 ");
		while($data=mysql_fetch_array($person)){
		echo "<option value=\"$data[id_person]\">$data[jenis_person]</option>";
		}
		?>
		</select></td>
		</tr></td></tr>
				
        </table>		<input value="Save" name="submit" type="submit" class="submit" onclick="save()"/> 
				<input value="Reset" type="reset" />
		</form></br>
			

				