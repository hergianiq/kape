<?php


 include_once("koneksi/koneksi.php");
  
	$id_siswa = $_POST ['id_siswa'];
     

		$tgl=	 $_POST['tgl_bayar'];	 
		 $bayar = $_POST['id_pembayaran']; 
		 $kary = $_POST['id_karyawan'];
                 
$query = mysql_query("insert into tb_bayar (id_siswa,id_pembayaran,tgl_bayar,id_karyawan) values ('$id_siswa','$bayar','$tgl','$kary')") or die (mysql_error());
if($query){
echo "<script>document.location='index.php?v=pembayaran';</script>";
}else{
echo "<script>document.location='index.php?v=forminputpembayaran';</script>";
}
?>