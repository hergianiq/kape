<?php

	
	if(isset($_SESSION['username'],$_SESSION['password'],$_SESSION['status'])){
		if($_SESSION['status']!=2){
			echo"<script>alert('Anda tidak berhak mengakses file ini!');document.location='../index.php';</script>";
		}
	}else{
		echo"<script>alert('Anda tidak berhak mengakses file ini!');document.location='../index.php';</script>";
	}
?>
<tr><td><a href="./">| Back |</td></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<!--
<tr>
<td><a href="?v=forminputsiswa"><img src="gambar/add.jpg" title="Input Siswa" height="30" width="25"></td></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<td><a href="?v=updatesiswa"><img src="gambar/edit.ico" title="Edit Siswa" height="30" width="25"></td></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<td><a href="?v=deletesiswa"><img src="gambar/delete.png" title="Edit Siswa" height="30" width="25"></td></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</tr></br>-->
		<a href="?v=forminputkelas" align="left">| Input Kelas |</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		

		
		<h2 align='center'><br>Daftar Kelas</h2><br>
		
	  <?php
	  $sql=mysql_query("select a.id_program, a.nama_program, a.id_karyawan, a.id_jenis_kelas, a.harga, a.jumlah_sesi, c.nama_karyawan, d.jenis_kelas
from tb_program a, tb_karyawan c, tb_jenis_kelas d where a.id_karyawan=c.id_karyawan and a.id_jenis_kelas=d.id_jenis_kelas	and a.id_program !='0'  ");
 
  ?>
     
       
        <table border="0" style="color:#000;" bgcolor="#000" width="100%" cellpadding="2" cellspacing="1">
          
		  <tr>
			<th  align="center" style="background:#5A5C5C" width="3%"><font color="#ffffff">NO</font></th>
			<th  align="center" style="background:#5A5C5C" width="14%"><font color="#ffffff">Nama Program</font></th>
			<th  align="center" style="background:#5A5C5C" width="10%"><font color="#ffffff">Jenis Kelas</font></th>
			<th  align="center" style="background:#5A5C5C" width="10%"><font color="#ffffff">Jumlah Sesi</font></th>
			<th  align="center" style="background:#5A5C5C" width="15%"><font color="#ffffff">Harga</font></th>
			<th  align="center" style="background:#5A5C5C" width="10%"><font color="#ffffff">Trainer</font></th>
					   <th  align="center" style="background:#5A5C5C" width="10%"><font color="#ffffff">Action</font></th>
			 
            </tr>
		
	<?php
		   $nomor=1;
		   while($data=mysql_fetch_array($sql))		  
		   {
		   		if(($nomor % 2)== 0){
		   			$bgcolor="#F7D891";
			}else{
				$bgcolor="#F7F6DE";
			}
				$nama= $data['id_program'];
		   ?>
                    
			<tr bgcolor="<?php echo $bgcolor;?>";>
			<td align="center" ><?php echo" $nomor"?></td>
			<td ><?php echo" $data[nama_program]"?></td>
			<td align="center" ><?php echo" $data[jenis_kelas]"?></td>
			<td align="center" ><?php echo" $data[jumlah_sesi]"?></td>
			<td align="center" ><?php echo" $data[harga]"?></td>
			<td align="center" ><?php echo" $data[nama_karyawan]"?></td>
			
			<td align="center" > <a href="?v=formupdatekelas&id_program=<?php echo $nama;?>"><font color="blue">Edit</font></a> | 
		<a href="?v=deletekelas&id_program=<?php echo $nama;?>" onclick= "return confirm ('Anda yakin akan menghapus?')"><font color="red">Delete</font></a></td>
            </tr>
		
			<?php 
			$nomor++; 
			}
			
			?>
      
        <?php echo "</table>"?>