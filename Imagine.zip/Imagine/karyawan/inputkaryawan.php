<?php

	 include_once("../koneksi/koneksi.php");
	 
	$id_karyawan = $_POST ['id_karyawan'];
     $nama = $_POST ['nama_karyawan'];
     $phone = $_POST ['phone_karyawan'];
     $email = $_POST ['email'];
	 $id_person = $_POST ['id_person'];
	
	$query= "insert into tb_karyawan (id_karyawan ,nama_karyawan ,phone_karyawan ,email ,id_person)values('$id_karyawan','$nama','$phone','$email','$id_person')";
	$hasil= mysql_query($query) or die (mysql_error());
if ($query){
	echo"<script>document.location='../?v=adminkaryawan';</script>";
	//header('location:?link=home');
}else{
	echo"<script>document.location='?v=forminputkaryawan';</script>";
	}
	
?>

