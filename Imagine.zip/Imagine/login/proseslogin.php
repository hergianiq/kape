<?php
include ("../koneksi/koneksi.php");
include ("../admin/fungsiadmin.php");
$logged_in=false;
session_start();

 $username_session=$_POST['username'];
 $pass_session=$_POST['password'];
 
 
 
if(isset($_POST['loginmanager'])){			// utk mengecek apakah halaman ini sudah yg dipilih atau bkn berdasarkan nama tombol yg dipilih
 $loginmanager=$_POST['loginmanager'];		
	$xx = "SELECT * FROM tb_login WHERE username='$username_session' AND password='$pass_session' AND status='Manager'";
	$select=mysql_query($xx);				// utk meminta data dari yg kita minta ke database dgn QUERY di atas
	$cek=mysql_num_rows($select);			// mengecek apakah di kolom database terdapat data yg diminta
	if($cek!=0){							// melakaukan pengecekan jika cek !=0 (berarti ada data dalam kolom) jika ada maka
		$data = mysql_fetch_array($select);	// maka mysql_fetch_array untuk mengambil data yg diminta
		isset($_SESSION['username']);		// baris 18-20 utk 
		isset($_SESSION['password']);
		isset($_SESSION['status']);
		$_SESSION['username'] = $username_session; // utk melakukan pengisian dalam SESSION username dalam database yg di input dgn variable USERNAME_SESSION
		$_SESSION['password'] = $pass_session;	
		$_SESSION['status'] = 1;
		header("location:../index.php");
}	
}
if(isset($_POST['loginfo'])){
 $loginfo=$_POST['loginfo'];
 $xx = "SELECT * FROM tb_login WHERE username='$username_session' AND password='$pass_session' AND status='FO'";
	$select=mysql_query($xx);
	$cek=mysql_num_rows($select);
	if($cek!=0){
		$data = mysql_fetch_array($select);
		isset($_SESSION['username']);
		isset($_SESSION['password']);
		isset($_SESSION['status']);
		$_SESSION['username'] = $username_session;
		$_SESSION['password'] = $pass_session;
		$_SESSION['status'] = 2;
		header("location:../index.php");
}	
}
if(isset($_POST['loginkeu'])){
 $loginkeuangan=$_POST['loginkeu'];
	$xx = "SELECT * FROM tb_login WHERE username='$username_session' AND password='$pass_session' AND status='Keuangan'";
	$select=mysql_query($xx);
	$cek=mysql_num_rows($select);
	if($cek!=0){
		$data = mysql_fetch_array($select);
		isset($_SESSION['username']);
		isset($_SESSION['password']);
		isset($_SESSION['status']);
		$_SESSION['username'] = $username_session;
		$_SESSION['password'] = $pass_session;
		$_SESSION['status'] = 3;
		header("location:../index.php");
	}
	}