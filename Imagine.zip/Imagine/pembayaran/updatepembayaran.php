<?php

 include_once("koneksi/koneksi.php");
  
	
		 $bayar = $_POST['id_pembayaran'];
		 $id = $_POST['id_bayar'];	
		 $id_kary = $_POST['id_karyawan'];	
		 $tgl =$_POST['tgl_bayar'];
                 
$query = mysql_query("UPDATE tb_bayar SET id_pembayaran='$bayar', id_karyawan='$id_kary', tgl_bayar='$tgl' WHERE id_bayar='$id'") or die (mysql_error());
if($query){
echo "<script>document.location='?v=pembayaran';</script>";
}else{
echo "<script>document.location='?v=formupdatepembayaran';</script>";
}
?>