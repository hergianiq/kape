<?php

	
	if(isset($_SESSION['username'],$_SESSION['password'],$_SESSION['status'])){
		if($_SESSION['status']!=2){
			echo"<script>alert('Anda tidak berhak mengakses file ini!');document.location='../index.php';</script>";
		}
	}else{
		echo"<script>alert('Anda tidak berhak mengakses file ini!');document.location='../index.php';</script>";
	}
?>
<tr><td><a href="./">| Back |</td></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<!--
<tr>
<td><a href="?v=forminputsiswa"><img src="gambar/add.jpg" title="Input Siswa" height="30" width="25"></td></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<td><a href="?v=updatesiswa"><img src="gambar/edit.ico" title="Edit Siswa" height="30" width="25"></td></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<td><a href="?v=deletesiswa"><img src="gambar/delete.png" title="Edit Siswa" height="30" width="25"></td></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</tr></br>-->
		<a href="?v=forminputpembayaran" align="left">| Input Pembayaran|</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		

		
		<h2 align='center'><br>Daftar Pembayaran Siswa</h2><br>
		
			
	  <?php
	  $sql=mysql_query("select a.id_siswa,a.nama_siswa, c.nama_program, c.harga,d.jenis_kelas, b.id_pembayaran, b.status_pembayaran, e.tgl_bayar,e.id_bayar, c.id_program, f.nama_karyawan from tb_siswa a, tb_pembayaran b, tb_program c, tb_jenis_kelas d, tb_karyawan f, tb_bayar e 
	  where a.id_status='1' and a.id_person='2'
	  and b.id_pembayaran=e.id_pembayaran and a.id_program=c.id_program and d.id_jenis_kelas=c.id_jenis_kelas and f.id_karyawan=e.id_karyawan and a.id_siswa=e.id_siswa");
 
 
	  
  ?>
  
       
        <table width="100%" cellpadding="2" border="1">
          
		  <tr>
			  <th  style="background:#5A5C5C" width="2%"><font color="#ffffff" >No</font></th>
				   <th  style="background:#5A5C5C" width="15%"><font color="#ffffff">Nama</font></th>
						<th  style="background:#5A5C5C" width="15%"><font color="#ffffff">Kelas</font></th>	
						<th  style="background:#5A5C5C" width="15%"><font color="#ffffff">Jenis Kelas</font></th>				 
				  <th  style="background:#5A5C5C" width="10%"><font color="#ffffff">Tanggal Bayar</font></th>
				<th  style="background:#5A5C5C" width="10%"><font color="#ffffff">Status Pembayaran</font></th>
				 <th  style="background:#5A5C5C" width="10%"><font color="#ffffff">Kekurangan</font></th>
	
	 <th  style="background:#5A5C5C" width="10%"><font color="#ffffff">Penerima</font></th>
			  		   <th  style="background:#5A5C5C" width="5%"><font color="#ffffff">Action</font></th>
			             </tr>
						 
		<?php
		   $nomor=1;
		   while($data=mysql_fetch_array($sql))		  
		   {
		   		if(($nomor % 2)== 0){
		   			$bgcolor="#F7D891";
			}else{
				$bgcolor="#F7F6DE";
			}
				$nama= $data['id_siswa'];
				$bayar=$data['id_bayar'];
				$a= $data['id_pembayaran'];
				$b= $data['harga'];
				if ($a="2")
				{
						$kekurangan=$b/2;
				}
				else { 
				$kekurangan=0;
				}
				?> 
                     <tbody>
			<tr bgcolor="<?php echo $bgcolor;?>";>
			 <td ><?php echo" $nomor"?></td>
			 <td><?php echo" $data[nama_siswa]"?></td>
			 <td><?php echo" $data[nama_program]"?></td>
			  <td><?php echo" $data[jenis_kelas]"?></td>	
			  <td><?php echo" $data[tgl_bayar]"?></td>
						  <td ><?php echo" $data[status_pembayaran]"?></td>	   <td ><?php echo "Rp  " . $kekurangan;?></td>	  
						  <td ><?php echo" $data[nama_karyawan]"?></td>
			 
			 <td> <a href="?v=formupdatepembayaran&id_bayar=<?php echo $bayar; ?>"><b>Update</b></a> 
		
            </tr>
		
			<?php 
			$nomor++; 
			}
			
			?>
          </tbody>
        <?php echo "</table>"?>