<?php
		 include_once("C:/xampp/htdocs/fix/koneksi/koneksi.php");
	
?>
<script type="text/javascript" src="js/jquery.min.js"></script>
		<script src="js/highcharts.js"></script>
		<script type="text/javascript" src="js/jquery161.js"></script>
		

		<script type="text/javascript">
		//2)script untuk membuat grafik, perhatikan setiap komentar agar paham
$(function () {
    var chart;
    $(document).ready(function() {
        chart = new Highcharts.Chart({
            chart: {
                renderTo: 'tampil', //letakan grafik di div id tampil
                //Type grafik, anda bisa ganti menjadi area,bar,column dan bar
                type: 'line',  
                marginBottom: 30
            },
            title: {
                text: 'Grafik Statistik Siswa',
                x: -20 //center
            },
            subtitle: {
                text: 'IMAGINE IT CENTER',
                x: -20
            },
           xAxis: [{categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun','Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']}],
		   yAxis: {
                title: {  //label yAxis
                    text: 'Total Peserta'
                    
                },
                plotLines: [{
                    value: 0,
                    width: 1,
                    color: '#000' //warna dari grafik line
                }]
            },
            tooltip: { 
            //fungsi tooltip, ini opsional, kegunaan dari fungsi ini 
            //akan menampikan data di titik tertentu di grafik saat mouseover
                formatter: function() {
                        return '<b>'+ this.series.name +'</b><br/>'+
                        this.x +': '+ this.y ;
                }
            },
            legend: {
                
                layout: 'vertical',
                        align: 'left',
                        x: 100,
                        verticalAlign: 'top',
                        y: 50,
                        floating: true,
            },
			//series adalah data yang akan dibuatkan grafiknya,
		
            series: [
			
				<?php
include "koneksi/koneksi.php";
	if(isset($_GET['data'])){
		$cr=addslashes($_GET['tgl_daftar']);
	}else{
		$cr=addslashes($_POST['tgl_daftar']);
	}
	$cari=preg_replace("/\s/","%",$cr);
	if($cari==''){ echo " Not Found 
	"; 
	}
 
	else{}
					$query= mysql_query("SELECT * FROM tb_program ");
					while($data=mysql_fetch_array($query)){
						$id = $data['id_program']
					?>{
						name:'<?php echo $data['nama_program'];?>',<?php
						$siswa = mysql_query("SELECT count(*) as jumlah FROM `tb_siswa` WHERE MONTH (tgl_daftar)='1' AND id_program='$id' and YEAR (tgl_daftar)='$cari'");//SELECT * FROM `tb_siswa` WHERE MONTH (tgl_daftar)='4' AND YEAR (tgl_daftar)='2012'
						$row = mysql_num_rows($siswa);
						$siswa2 = mysql_query("SELECT count(*) as jumlah FROM `tb_siswa` WHERE MONTH (tgl_daftar)='2' AND id_program='$id' YEAR (tgl_daftar)='$cari'");
						$row2 = mysql_num_rows($siswa2);
						$siswa3 = mysql_query("SELECT count(*) as jumlah FROM `tb_siswa` WHERE MONTH (tgl_daftar)='3' AND id_program='$id' YEAR (tgl_daftar)='$cari'");
						$row3 = mysql_num_rows($siswa3);
						$siswa4 = mysql_query("SELECT count(*) as jumlah FROM `tb_siswa` WHERE MONTH (tgl_daftar)='4' AND id_program='$id' YEAR (tgl_daftar)='$cari'");
						$row4 = mysql_num_rows($siswa4);
						$siswa5 = mysql_query("SELECT count(*) as jumlah FROM `tb_siswa` WHERE MONTH (tgl_daftar)='5' AND id_program='$id' YEAR (tgl_daftar)='$cari'");
						$row5 = mysql_num_rows($siswa5);
						$siswa6 = mysql_query("SELECT count(*) as jumlah FROM `tb_siswa` WHERE MONTH (tgl_daftar)='6' AND id_program='$id' YEAR (tgl_daftar)='$cari'");
						$row6 = mysql_num_rows($siswa6);
						$siswa7 = mysql_query("SELECT count(*) as jumlah FROM `tb_siswa` WHERE MONTH (tgl_daftar)='7' AND id_program='$id' YEAR (tgl_daftar)='$cari'");
						$row7 = mysql_num_rows($siswa7);
						$siswa8 = mysql_query("SELECT count(*) as jumlah FROM `tb_siswa` WHERE MONTH (tgl_daftar)='8' AND id_program='$id' YEAR (tgl_daftar)='$cari'");
						$row8 = mysql_num_rows($siswa8);
						$siswa9 = mysql_query("SELECT count(*) as jumlah FROM `tb_siswa` WHERE MONTH (tgl_daftar)='9' AND id_program='$id' YEAR (tgl_daftar)='$cari'");
						$row9 = mysql_num_rows($siswa9);
						$siswa10 = mysql_query("SELECT count(*) as jumlah FROM `tb_siswa` WHERE MONTH (tgl_daftar)='10' AND id_program='$id' YEAR (tgl_daftar)='$cari'");
						$row10 = mysql_num_rows($siswa10);
						$siswa11 = mysql_query("SELECT count(*) as jumlah FROM `tb_siswa` WHERE MONTH (tgl_daftar)='11' AND id_program='$id' YEAR (tgl_daftar)='$cari'");
						$row11 = mysql_num_rows($siswa11);
						$siswa12 = mysql_query("SELECT count(*) as jumlah FROM `tb_siswa` WHERE MONTH (tgl_daftar)='12' AND id_program='$id' YEAR (tgl_daftar)='$cari'");
						$row412 = mysql_num_rows($siswa12);
						
						
						
						$lima = 5;
						$no =1;
							$da = mysql_fetch_array($siswa);
							$da2 = mysql_fetch_array($siswa2);
							$da3 = mysql_fetch_array($siswa3);
							$da4 = mysql_fetch_array($siswa4);
							$da5 = mysql_fetch_array($siswa5);
							$da6 = mysql_fetch_array($siswa6);
							$da7 = mysql_fetch_array($siswa7);
							$da8 = mysql_fetch_array($siswa8);
							$da9= mysql_fetch_array($siswa9);
							$da10 = mysql_fetch_array($siswa10);
							$da11= mysql_fetch_array($siswa11);
							$da12= mysql_fetch_array($siswa12);
							

                            $blue = $lima * 6;
							$warna = $blue.'#CF261F';
							
								?>
								color:'$warna',
								type:'column',
								yaxis:1,
								data:[<?php echo $da['jumlah'];?>,<?php echo $da2['jumlah'];?>,
										<?php echo $da3['jumlah'];?>,<?php echo $da4['jumlah'];?>,
										<?php echo $da5['jumlah'];?>,<?php echo $da6['jumlah'];?>,
										<?php echo $da7['jumlah'];?>,<?php echo $da8['jumlah'];?>,
										<?php echo $da9['jumlah'];?>,<?php echo $da10['jumlah'];?>,
										<?php echo $da11['jumlah'];?>,<?php echo $da12['jumlah'];?>,]

								}
                                <?php
								$lima = $lima *3;	
								if($no == $row){ ?>,<?php }
								$no++;
					}
				//}
			?>
            ],
            
        });
    });
    
});
		</script>
<!--grafik akan ditampilkan disini -->
<a href = index.php>| Back |</a>
<form  name="form" method="post" action='b.php' vlign="right">

&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
Lihat Berdasarkan Tahun : 

				<td><select   name="tgl_daftar" onchange="this.form.submit()" >
							<option value="">- Tahun -</option> <?php echo $cari; ?>
							<?php

	$artikel=mysql_query("SELECT distinct YEAR(tgl_daftar) from tb_siswa");

	while ($baris=mysql_fetch_array($artikel)){
	
	$baris2=$baris['YEAR(tgl_daftar)'];
	
echo "<option value=\"$baris2\">$baris2</option>";	
										}
							?> 
							

							</select></td>
							</form>

<div id="tampil" style="min-width: 900px; height: 400px; margin: 0 auto">
</div>
