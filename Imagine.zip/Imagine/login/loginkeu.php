
   <title>jQuery Validation</title>
   <script src="js/jquery.js"></script>
   <script src="js/jquery.validate.js"></script>
   <script>
       $(document).ready(function(){
           $("#formku").validate();
        });
   </script>

   <style type="text/css">
       label.error {
           color: red; padding-left: .5em;
       }
   </style>
   </p>
 <h2 align="center"> Login Keuangan</h2> </p>
     
 <<form id="formku" action="login/proseslogin.php" method="POST">
       <table border="0">
	   
				<!--validasi dapat di rubah di file jquery.validasi-->
          <tr><td>Username</td><td>:</td><td><input type="text" name="username" class="required" minlength="3" /></td></tr>
          <tr><td>Password</td><td>:</td><td><input type="password" name="password" class="required" /></td></tr>
       </table>
       
			
		<p>
			<?php
			  $url = htmlspecialchars($_SERVER['HTTP_REFERER']);
			  echo "<a href='$url'>Back</a>"; 
			?>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
			<input class="submit" type="submit" value="Submit" name="loginkeu"/>
       
		</p>
	   
	   
			
     </form>
			
		
		 
		</form>
</p>	
			
            