<script src="js/jquery.js"></script>
<script src="js/jquery.validate.js"></script>
<script type="text/javascript">
$(document).ready(function(){

});
</script>
<script type="text/javascript">
   function save(){
        /* ambil data dari form */
         $.ajax({
  url: 'kelas/updatekelas.php',
  type: "POST",
  success: function(){
    alert('Failure');
  },
  error: function(){
    alert('Succes');
  }
});
   }
   </script>
  <?php

 include_once("koneksi/koneksi.php");
   ?>
    <?php
		$id = addslashes($_GET['id_program']);
	  $sql=mysql_query("select a.id_program, a.nama_program, a.id_karyawan, a.id_jenis_kelas, a.harga, a.jumlah_sesi, c.nama_karyawan, d.jenis_kelas
from tb_program a, tb_karyawan c, tb_jenis_kelas d where a.id_program='$id' and a.id_karyawan=c.id_karyawan and a.id_jenis_kelas=d.id_jenis_kelas	and a.id_program !='0'  ");
 
$nama = mysql_fetch_array($sql);
  ?>
   <a href="?v=kelas">| Back |</a>
					

			<h2 align='center'><br>UPDATE KELAS</h2><br><br>
			
			
			<form name="form1" method="post" action="?v=updatekelas">	
		<table>
							<tr><td><input type="hidden" name="id_program" /></td></tr>
							<tr><td>Nama Program</td><td><input type="text" name="nama_program"  value="<?php echo $nama['nama_program'];?>" /></td></tr>
						
							<tr><td>Jenis Kelas</td><td><select  name="id_jenis_kelas"  >
							<option value="<?php echo $nama['id_jenis_kelas'];?>"><?php echo $nama['jenis_kelas'];?></option>
							<?php

							$person=mysql_query("SELECT * FROM tb_jenis_kelas ");
								while($data=mysql_fetch_array($person)){
									echo "<option value=\"$data[id_jenis_kelas]\">$data[jenis_kelas]</option>";		}
							?>
							
							
					</select></td></tr>
							<tr><td>Jumlah Sesi</td><td><input type="text" name="jumlah_sesi"   value="<?php echo $nama['jumlah_sesi'];?>"/></td></tr>
							<tr><td>Harga</td><td><input type="text" name="harga"  value="<?php echo $nama['harga'];?>" /></td></tr>
							<tr><td>Trainer</td><td>
							
							<SELECT name="id_karyawan" >
							<option value="<?php echo $nama['id_karyawan'];?>"><?php echo $nama['nama_karyawan'];?></option>
							<?php

							$person=mysql_query("SELECT * FROM tb_karyawan where id_person='3'");
								while($a=mysql_fetch_array($person)){
									echo "<option value=\"$a[id_karyawan]\">$a[nama_karyawan]</option>";		}
							?></select></td></tr>
							<tr><td><input value="Save" name="Save" type="submit" onclick="save()"/></td>
								<td><input value="Reset" type="reset" /></td></tr>
							
					</table>
					</form>	
				<center>
								</center>
							
		