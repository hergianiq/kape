<?php
	 include_once("koneksi/koneksi.php");
	//include ("koneksi/koneksi.php");
	
	if(!isset($_GET['id_karyawan'])){
?>
<tr><td><a href="?v=adminkaryawan">| Back |</td></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<br><h2 align='center'><br>Daftar Nama Karyawan</h2><br>
			<p align="center">
				<?php
	  $sql=mysql_query("select tb_karyawan.id_karyawan, tb_karyawan.nama_karyawan, tb_karyawan.phone_karyawan, tb_karyawan.email, tb_person.jenis_person from tb_karyawan inner join tb_person on tb_karyawan.id_person=tb_person.id_person");
	  ?>
     
               <table  border="1" width="100%" cellpadding="4">
          
		  <tr>
			  <th  style="background:#5A5C5C"><font color="#ffffff" width="5">No</font></th>
				   <th  style="background:#5A5C5C"><font color="#ffffff" width="5">Id</font></th>
					  <th  style="background:#5A5C5C"><font color="#ffffff" width="10">Nama</font></th>
						<th  style="background:#5A5C5C"><font color="#ffffff">Phone</font></th>
						  <th  style="background:#5A5C5C"><font color="#ffffff">Email</font></th>
			   <th  style="background:#5A5C5C"><font color="#ffffff">Jabatan</font></th>			
			   <th  style="background:#5A5C5C"><font color="#ffffff">Action</font></th>
		
			 
            </tr>
		
		   <?php
		   $nomor=1;
		   while($data=mysql_fetch_array($sql))		  
		   {
				$id= $data['id_karyawan'];
		   ?>
           <tbody>
			<tr>
			 <td ><?php echo" $nomor"?></td>
			  <td ><?php echo" $data[id_karyawan]"?></td>
			  <td><?php echo" $data[nama_karyawan]"?></td>
			  <td><?php echo" $data[phone_karyawan]"?></td>
			  <td ><?php echo" $data[email]"?></td>
			  <td><?php echo" $data[jenis_person]"?></td>
				<td><a href="?v=updatekaryawan&id_karyawan=<?php echo "$data[id_karyawan]"?>">Edit</td></a>
            </tr>
		
			<?php 
			$nomor++; 
			}
			?>
			
          </tbody>
        </table>
			</p>
<?php
	}else{
		$idsiswa = addslashes($_GET['id_karyawan']);
		//echo $idsiswa;
		include "formupdatekaryawan.php";
	}
	?>			