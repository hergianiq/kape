<?php
require_once "koneksi/koneksi.php";
session_start();

if(isset($_SESSION['username'],$_SESSION['password'],$_SESSION['status'])){//jika user sudah login
	if($_SESSION['status']==1){//pilih status jika status=1 maka user tersebut adalah manager
		$content = "link/manager.php";//tampilkan link buat user manager
	}else if($_SESSION['status']==2){//pilih status jika status=1 maka user tersebut adalah fo
		$content = "link/fo.php";//tampilkan link buat user fo
	}else if($_SESSION['status']==3){//pilih status jika status=1 maka user tersebut adalah keuangan
		$content ="link/keuangan.php";//tampilkan link buat user keuangan
	}
}else{
	$content = "link/link.php";//tampilkan link ini jika user belum login
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="author" content="realitysoftware.ca" />
<title></title>
<link rel="stylesheet" type="text/css" href="css/style.css"/>

</head>

<body>

<div id="container">

			<div id="header">
			<img width="600" height="120" title="Imagine IT Center" src="gambar/imagine11.jpg" style="padding-left: 100px;">
			</div>
			<center>
			<div id="menu">
				<?php 
				//		require "menu.php";
				?>
				
			</div></center>

<!--			<div id="sidebar">
									
			</div>
-->
			<div id="main">
			<!-- content -->
			<?php
				include "$content";
			?>
			
			</div>

			<div id="footer"></a><span class="separator">|</span>
			&copy;Imagine IT Center &nbsp;<span class="separator">|</span>&nbsp; Design by 
			<a href="http://www.realitysoftware.ca" title="Website Design">Imagine</a>
			</div>

</div>

</body>
</html>