<?php
	 include_once("koneksi/koneksi.php");
	//include ("koneksi/koneksi.php");
?>
			<a href="?v=logout">| Logout |</a>
<p>
				
				<table ALIGN="CENTER">
				<tr><td align="center"><a href="?v=adminsiswa"><img width="100" height="120" title="Siswa" src="gambar/siswa.gif" style="padding-right: 30PX; padding-left: 30PX; padding-bottom: 15px;"></a><br>
				<Font size=2 color="#5A5C5C"><b>SISWA</b></font>
				</td><td align="center"><a href="?v=absensi"><img src="gambar/X.png" title="Absensi" height="120" width="120" style="padding-right: 30PX; padding-left: 30PX; padding-bottom: 15px;"></a><br>
				<Font size=2 color="#5A5C5C"><b>ABSENSI</b></font>
				</td><td align="center"><a href="?v=pembayaran"><img src="gambar/checkout.PNG" title="Trainer" height="120" width="120" style="padding-right: 30PX; padding-left: 30PX; padding-bottom: 15px;"></a><br>
				<Font size=2 color="#5A5C5C"><b>PEMBAYARAN</b></font>
				</td><td align="center"><a href="?v=adminkaryawan"><img src="gambar/karyawan.png" title="Trainer" height="120" width="120" style="padding-right: 30PX; padding-left: 30PX; padding-bottom: 15px;"></a><br>
				<Font size=2 color="#5A5C5C"><b>KARYAWAN</b></font>
				</tr>
				<TR></TR>
				<tr>
				<td align="center"><a href="?v=statistik"><img src="gambar/stk.JPG" title="Trainer" height="120" width="120" style="padding-right: 30PX; padding-left: 30PX; padding-bottom: 15px; padding-top: 35px;"></a><br>
				<Font size=2 color="#5A5C5C"><b>STATISTIK</b></font>
				<td align="center"><a href="?v=kelas"><img src="gambar/programs.png" title="Trainer" height="120" width="120" style="padding-right: 30PX; padding-left: 30PX; padding-bottom: 15px; padding-top: 35px;"></a><br>
				<Font size=2 color="#5A5C5C"><b>KELAS</b></font>
				<td align="center"><a href="?v=formjadwal"><img src="gambar/ABSEN.PNG" title="Trainer" height="120" width="120" style="padding-right: 30PX; padding-left: 30PX; padding-bottom: 15px; padding-top: 35px;"></a><br>
				<Font size=2 color="#5A5C5C"><b>JADWAL</b></font>
				</tr>
				
				
				</table>
				