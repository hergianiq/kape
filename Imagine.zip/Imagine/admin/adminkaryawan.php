<?php
	include "koneksi/koneksi.php";
?>

<a href="./">| Back |</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<!--<p align="right"><tr>
<td><a href="?v=forminputkaryawan"><img src="gambar/add.jpg" title="Input karyawan" height="70" width="70"></td></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<td><a href="?v=updatekaryawan"><img src="gambar/edit.ico" title="Edit karyawan" height="70" width="70"></td></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<td><a href="?v=deletekaryawan"><img src="gambar/delete.png" title="Edit karyawan" height="70" width="70"></td></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</tr></br>
<tr><td><Font color="#5A5C5C"><b>Input Karyawan</b></font></td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<tr><td><Font color="#5A5C5C"><b>Edit Karyawan</b></font></td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<tr><td><Font  color="#5A5C5C"><b>Delete Karyawan</b></font></td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</tr>-->
<a href="?v=forminputkaryawan">| Input Karyawan |</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<!--<a href="?v=formupdatekaryawan">| Edit Karyawan |</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<a href="a">| Delete Karyawan |</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
-->
<br><br><h2 align='center'>Daftar Nama Karyawan</h2><br>
		<?php	
 $sql=mysql_query("select tb_karyawan.id_karyawan, tb_karyawan.nama_karyawan, tb_karyawan.phone_karyawan, tb_karyawan.email, tb_person.jenis_person from tb_karyawan inner join tb_person on tb_karyawan.id_person=tb_person.id_person");
		?>
		<center>
        <table  border="0" style="color:#000;" bgcolor="#000" width="88%" cellpadding="1" cellspacing="1">
          
		  <tr>
			  <th  style="background:#5A5C5C" width="3%" align="center"><font color="#ffffff">No</font></th>
			   <th  style="background:#5A5C5C" width="3%" align="center"><font color="#ffffff">Id</font></th>
              <th  style="background:#5A5C5C" width="20%" align="center"><font color="#ffffff">Nama</font></th>
              <th  style="background:#5A5C5C" width="15%"align="center"><font color="#ffffff">Phone</font></th>
			  <th  style="background:#5A5C5C" width="20%"align="center"><font color="#ffffff">Email</font></th>
			  <th  style="background:#5A5C5C" width="10%"align="center"><font color="#ffffff">Jenis Person</font></th>
			    <th  style="background:#5A5C5C" width="10%"align="center"><font color="#ffffff">Action</font></th>

			  </tr>
		 <?php
		 			
		   $nomor=1;
		   while($data=mysql_fetch_array($sql))		  
		   { if(($nomor % 2)== 0){
		   			$bgcolor="#F7D891";
			}else{
				$bgcolor="#F7F6DE";
			}
				$id= $data['id_karyawan'];
		   ?>
           <tbody>
		
			<tr bgcolor="<?php echo $bgcolor;?>";>
			  <td align="center" ><?php echo" $nomor"?></td>
			  <td align="center" ><?php echo" $data[id_karyawan]"?></td>
			  <td align="center" ><?php echo" $data[nama_karyawan]"?></td>
			  <td align="center" ><?php echo" $data[phone_karyawan]"?></td>
			  <td align="center" ><?php echo" $data[email]"?></td>
			  <td align="center" ><?php echo" $data[jenis_person]"?></td>			 
 <td align="center" > <a href="?v=formupdatekaryawan&id_karyawan=<?php echo "$id"?>"><font color="blue">Edit</font></a> | 
		<a href="?v=prosesdeletekaryawan&id_karyawan=<?php echo "$id"?>" onclick= "return confirm ('Anda yakin akan menghapus?')"><font color="Red">Delete</font></a></td>			  
			 
            </tr>
		
			<?php 
			$nomor++; 
			}
		
			?>
			
          </tbody>
     <?php	echo "</table>"; ?>
		</center>
		