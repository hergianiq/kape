<?php

 include_once("koneksi/koneksi.php"); 

	
		$id= $_GET['id_karyawan']; 	
$query = mysql_query("delete from tb_karyawan where id_karyawan='$id'") or die (mysql_error());

if($query){
	echo "<script>
	 
		  document.location='?v=adminkaryawan';
		  	  return true;
   </script>";
}else{
echo "<script>alert('Delete Failed');document.location='?v=adminkaryawan';</script>";
}
?>
