<?php


 include_once("koneksi/koneksi.php");
  
	
     

		 
		 $bayar = $_POST['id_siswa']; 
		 $kary = $_POST['id_program'];
                 
$query = mysql_query("insert into tb_absensi (id_absensi,id_siswa,id_program,jumlah_izin,jumlah_hadir,jumlah_sakit) values ('','$bayar','$kary','','','')") or die (mysql_error());
if($query){
echo "<script>document.location='index.php?v=absensi';</script>";
}else{
echo "<script>document.location='index.php?v=forminputabsensi';</script>";
}
?>