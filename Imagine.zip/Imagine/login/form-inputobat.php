<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<title>pendaftaran user</title>

		<style type="text/css">
		.labelfrm {
			display:block;
			font-size:small;
			margin-top:5px;
		} .error { font-size:small; color:red; }
		</style>

</head>

<body>
																<?php
																if($_POST["tombol"]=="submit"){
																//registrasi variable
																	$Id_obat		= $_POST["id_obat"];
																	
																//validasi form tidak boleh kosong
																	if($Id_obat == ""){$errorId_obat="Id_obat tidak boleh kosong...";}
																	
																
																}
																
	<h1>Input Nama Obat</h1>
		<form action="" method="post" id="admin">
		
			<label for="id_obat" class="labelfrm">Id_obat: </label>
			<input type="text" name="id_obat" id="id_obat" size="30" value="<?php echo"$Id_obat"; ?>">
			<?php
			if($errorId_obat){echo"<div style='color:red; font-size:10pt'>$errorId_obat</div>";}
			?>
 
            
			<label for="submit" class="labelfrm">&nbsp;</label>
			<input type="submit" name="tombol" value="Simpan">
            <label for="reset" class="">&nbsp;</label>
			<input type="submit" name="reset" value="Clear"/>
		</form>

</body>
</html>