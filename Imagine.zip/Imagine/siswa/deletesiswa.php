<?php
	 include_once("C:/xampp/htdocs/fix/koneksi/koneksi.php");
	//include ("koneksi/koneksi.php");
?>

<tr><td><a href="?v=adminsiswa">| Back |</td></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<br><h2 align='center'><br>Daftar Nama Siswa</h2><br>
			<p align="center">
				<?php
	  $sql=mysql_query("select tb_siswa.id_siswa, tb_siswa.nama_siswa, tb_siswa.phone, tb_siswa.kampus,tb_siswa.tgl_daftar, tb_person.jenis_person from tb_siswa inner join tb_person on tb_siswa.id_person=tb_person.id_person");
	  ?>
     
               <table  border="1" width="100%" cellpadding="4">
          
		  <tr>
			  <th  style="background:#5A5C5C"><font color="#ffffff" width="5">No</font></th>
				   <th  style="background:#5A5C5C"><font color="#ffffff" width="5">Id</font></th>
					  <th  style="background:#5A5C5C"><font color="#ffffff" width="10">Nama</font></th>
						<th  style="background:#5A5C5C"><font color="#ffffff">Phone</font></th>
					  <th  style="background:#5A5C5C"><font color="#ffffff">Kampus</font></th>
				  <th  style="background:#5A5C5C"><font color="#ffffff">Tanggal Daftar</font></th>
			   <th  style="background:#5A5C5C"><font color="#ffffff">Status</font></th>			
			   <th  style="background:#5A5C5C"><font color="#ffffff">Action</font></th>
		
			 
            </tr>
		
		   <?php
		   $nomor=1;
		   while($data=mysql_fetch_array($sql))		  
		   {
				$id= $data['id_siswa'];
		   ?>
           <tbody>
			<tr>
			 <td ><?php echo" $nomor"?></td>
			  <td ><?php echo" $data[id_siswa]"?></td>
			  <td><?php echo" $data[nama_siswa]"?></td>
			  <td><?php echo" $data[phone]"?></td>
			  <td ><?php echo" $data[kampus]"?></td>
			  <td ><?php echo" $data[tgl_daftar]"?></td>
			  <td><?php echo" $data[jenis_person]"?></td>
				<td><a href="siswa/prosesdelete.php?id_siswa=<?php echo "$data[id_siswa]"?>">Delete</td></a>
            </tr>
		
			<?php 
			$nomor++; 
			}
			?>
			
          </tbody>
        </table>
		
	
			</p>	