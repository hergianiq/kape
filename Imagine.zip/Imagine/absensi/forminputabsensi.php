<script type="text/javascript">
$(document).ready(function(){

});
</script>
<script type="text/javascript">
   function save(){
        /* ambil data dari form */
         $.ajax({
  url: 'kelas/inputkelas.php',
  type: "POST",
  success: function(){
    alert('Failure');
  },
  error: function(){
    alert('Succes');
  }
});
   }
   </script> 
 <?php

 include_once("koneksi/koneksi.php");
   ?>
   <a href="?v=absensi">| Back |</a></br>
					

			<h2 align='center'><br>INPUT ABSENSI SISWA</h2><br><br>
			
			
			<form id="formku" name="fomr1" method="post" action="?v=inputabsensi"/>		
		<table>
							<tr><td><input type="hidden" name="id_absensi" class="required"/></td></tr>
													
						<tr><td>Nama Siswa</td><td><select  name="id_siswa" >
							<option value="">- Pilih Siswa - </option>
							<?php

							$person=mysql_query("SELECT * FROM tb_siswa where id_status='1' and id_person='2' ");
								while($data=mysql_fetch_array($person)){
									echo "<option value=\"$data[id_siswa]\">$data[nama_siswa]</option>";		}
							?>
					</select></td></tr>
					
					<tr><td>Program Kelas</td><td><select  name="id_program" >
							<option value="">- Pilih Program - </option>
							<?php

							$person=mysql_query("SELECT * FROM tb_program where id_program !='0' ");
								while($data=mysql_fetch_array($person)){
									echo "<option value=\"$data[id_program]\">$data[nama_program]</option>";		}
							?>
					</select></td></tr>
					
							<tr><td><input value="Save" name="Save" type="submit" onclick="save()"/></td>
								</tr>
							
					</table>
					</form>	</br>
				<center>
								</center>
							
		