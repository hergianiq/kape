<?php
	if(!isset($_GET['v'])){
		require_once"admin/fo.php";
	}else if($_GET['v']=='adminsiswa'){
		require_once"admin/adminsiswa.php";
	}else if($_GET['v']=='forminputsiswa'){
		require_once"siswa/forminputsiswa.php";
	}else if($_GET['v']=='updatesiswa'){
		require_once"siswa/updatesiswa.php";
	}else if($_GET['v']=='formupdatesiswa'){
		require_once"siswa/formupdatesiswa.php";
	}else if($_GET['v']=='adminkaryawan'){
		require_once"admin/adminkaryawan.php";
	}else if($_GET['v']=='prosesdelete'){
		require_once"siswa/prosesdelete.php";
	}else if($_GET['v']=='forminputkaryawan'){
		require_once"karyawan/forminputkaryawan.php";
	}else if($_GET['v']=='formupdatekaryawan'){
		require_once"karyawan/formupdatekaryawan.php";	
	}else if($_GET['v']=='prosesdeletekaryawan'){
		require_once"karyawan/prosesdeletekaryawan.php";
		}else if($_GET['v']=='search'){
		require_once"siswa/search.php";
		}else if($_GET['v']=='inputsiswa'){
		require_once"siswa/inputsiswa.php";
		}else if($_GET['v']=='class'){
		require_once"siswa/class.php";
	}else if($_GET['v']=='logout'){
		require_once"login/logout.php";
	}else if($_GET['v']=='statistik'){
		require_once"grafik/stk1.php";
		}else if($_GET['v']=='pembayaran'){
		require_once"admin/adminpembayaran.php";
		}else if($_GET['v']=='forminputpembayaran'){
		require_once"pembayaran/forminputpembayaran.php";
		}else if($_GET['v']=='inputpembayaran'){
		require_once"pembayaran/inputpembayaran.php";
		}else if($_GET['v']=='formupdatepembayaran'){
		require_once"pembayaran/formupdatepembayaran.php";
		}else if($_GET['v']=='updatepembayaran'){
		require_once"pembayaran/updatepembayaran.php";
		}else if($_GET['v']=='kelas'){
		require_once"admin/adminkelas.php";
		}else if($_GET['v']=='forminputkelas'){
		require_once"kelas/forminputkelas.php";
		}else if($_GET['v']=='inputkelas'){
		require_once"kelas/inputkelas.php";
	}else{
		require_once"siswa/search.php";
	}

?>